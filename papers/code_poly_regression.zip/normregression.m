close all;
clear all;
rng(135461);
flag_jdt = 0;
if flag_jdt
    n = 5;
else
    n = 1000;
end;

%x = -1 + 2*rand(n,1);
x = (-1:2/(n-1):1)';
y = 2*(x.^2).*exp(x) + normrnd(0,1, n,1);
%plot(x,y);



maxm = 20;
X = legendreP(repmat(0:maxm-1, n,1), repmat(x,1,maxm));


Am_ = 1; % prior on m is exp(-A_*m)*[exp(A_)-1]
b_ = zeros(maxm,1);
hb_ = 1;
m0 = 3;
b0 = inv(X(:,1:m0)'*X(:,1:m0))*X(:,1:m0)'*y;
% hold on;
% plot(x,X(:,1:m0)*b0);
Hb_ = hb_*eye(maxm);

simN = 100000;
sim_m = zeros(1,simN);
b = b0;
m_sim(1) = m0;
m = m0;

acc_count = 0;

pred_mean_condp = zeros(simN,n);
pred_mean_condp(1,:)=(X(:,1:m)*b)';

for sim = 2:simN
   
   H_post = Hb_(1:m,1:m) + X(:,1:m)'*X(:,1:m); 
   V_post = inv(H_post);
   b_post =  V_post*(Hb_(1:m,1:m)*b_(1:m,1)+ X(:,1:m)'*y);
   b = mvnrnd(b_post,V_post)';
   pred_mean_condp(sim,:)=(X(:,1:m)*b)';
 
   if rand < 0.5 && m < maxm %try ms = m+1
       
       bs = DrawProp(y, X, b, m, Hb_, b_);
       logPropPdf = PropLogDensity(bs, y, X, b, m, Hb_, b_);
       
       logAccR = -Am_ + LogLklhd(y, X(:,1:m+1), [b;bs]) + LogNormPdf(bs, b_(m+1), Hb_(m+1,m+1)); % numerator
       logAccR = logAccR - (LogLklhd(y, X(:,1:m), b) + logPropPdf);%denominator
       
       if rand < exp(logAccR)
           acc_count = acc_count + 1;
           m = m+1;
           b = [b;bs];
       end
   elseif m>1 %try ms = m-1
       logPropPdf = PropLogDensity(b(m), y, X, b(1:m-1,1), m-1, Hb_, b_);
        
       logAccR = Am_ + LogLklhd(y, X(:,1:m-1), b(1:m-1,1)) + logPropPdf; % numerator
       logAccR = logAccR - (LogLklhd(y, X(:,1:m), b) + LogNormPdf(b(m), b_(m), Hb_(m,m)));%denominator
       
       if rand < exp(logAccR)
           acc_count = acc_count + 1;
           m = m-1;
           b = b(1:m,1);
       end     
       
   end
    
   sim_m(sim) = m; 
   
   if flag_jdt
       
       if length(b) ~= m
           stop = 1;
       end
       
        y = X(:,1:m)*b + normrnd(0,1, n,1);    
   end



   
end

acc_count/simN

figure(1)
plot(x,2*(x.^2).*exp(x),'LineWidth', 2, 'LineStyle', '--', 'Color', 'k')
hold on
scatter(x, y, '.', 'MarkerEdgeColor', 'k'); hold on
pred_mean = mean(pred_mean_condp);
plot(x,pred_mean,'LineWidth', 2, 'Color', 'k');%, 'LineStyle', '--')
xlabel('x');
ylabel('Y, E(Y|x=x)');
legend('true','data',  'posterior mean')

% 
% 
% figure(2)
% plot(sim_m)



freqm = zeros(1,max(sim_m));

probm = exp(-Am_*(1:max(sim_m)))*(exp(Am_)-1);%knowm pmf constant
m_prior_mean = 1./(1-exp(-Am_));

batch_len = 100;
test_series = sim_m - m_prior_mean;
if flag_jdt
    t_stat_m = mean(test_series)./ bmse(test_series,batch_len )
end

ts_filter = 1:simN;

for msupp = 1:max(sim_m)
   freqm(msupp) = sum(sim_m == msupp)./length(sim_m);
end
figure(3)
%subplot(1,2,1);
scatter(1:length(squeeze(sim_m(ts_filter))),squeeze(sim_m(ts_filter)), '.', 'MarkerEdgeColor', 'k');%plot(squeeze(sim_m(ts_filter)));

hold on;
xlabel('iterations');
ylabel('m');

%subplot(1,2,2);
figure(4)
%scatter(1:length(freqm),freqm,'filled', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'k');%plot(freqm)
scatter(1:length(freqm),freqm, 'MarkerEdgeColor', 'k');%plot(freqm)
hold on;
scatter(1:length(probm),probm, 's', 'MarkerEdgeColor', 'k')%plot(probm,'LineStyle','--')
legend('mcmc post pmf','prior pmf')
xlabel('m')
ylabel('Pr(m)')
%title('m');

if flag_jdt
    ind_j = find(probm*simN > 100); % test only values of m for wich effective sample size at least 100 
    for j = ind_j
        test_series = sim_m == j;
        t_stat_probmej = (mean(test_series)-probm(j))./ bmse(test_series,batch_len );
        [j, t_stat_probmej]
    end
end

% %check if obtained mcmc results match analytical expressions for marginal likelihood * prior
if ~flag_jdt
    logMargL = zeros(1,max(sim_m));
    for m = 1:max(sim_m)
        b = inv(X(:,1:m)'*X(:,1:m))*X(:,1:m)'*y;
        logMargL(m) =  - n*0.5*log(2*pi) -0.5*(y-X(:,1:m)*b)'*(y-X(:,1:m)*b) + lnnormpdf(b,b_(1:m),Hb_(1:m,1:m));
        H_post = Hb_(1:m,1:m) + X(:,1:m)'*X(:,1:m); 
        V_post = inv(H_post);
        b_post =  V_post*(Hb_(1:m,1:m)*b_(1:m,1)+ X(:,1:m)'*y);
        logMargL(m) = logMargL(m) - lnnormpdf(b,b_post,H_post); 
    end

    logMLxPi = logMargL +  -Am_*(1:max(sim_m)) + log((exp(Am_)-1));
    NormMLxPi = exp(logMLxPi - max(logMLxPi));
    NormMLxPi = NormMLxPi/sum(NormMLxPi);
    figure(4)
    hold on
    %subplot(1,2,2);
    %plot(NormMLxPi,'LineStyle','.-')
    scatter(1:length(NormMLxPi),NormMLxPi,[],'d', 'MarkerEdgeColor', 'k');
    legend('mcmc post pmf','prior pmf', 'exact post pmf')
end



function l = LogLklhd(y, X, b)
l = -0.5*(y-X*b)'*(y-X*b);
end

function [mbs, Hbs, Vbs] = ProposalParam(y, X, b, m, H_, b_)
Hbs = H_(m+1) + X(:,m+1)'*X(:,m+1);
Vbs = inv(Hbs);
ymp1 = y - X(:,1:m)*b(1:m,1);
mbs = Vbs*(H_(m+1)*b_(m+1)+ X(:,m+1)'*ymp1);
end

function bs = DrawProp(y, X, b, m, H_, b_)
[mbs, Hbs, Vbs] = ProposalParam(y, X, b, m, H_, b_);
bs = mvnrnd(mbs,Vbs);
end

function lp = PropLogDensity(bs, y, X, b, m, H_, b_)
[mbs, Hbs, Vbs] = ProposalParam(y, X, b, m, H_, b_);
%lp = 0.5*( - log(2*pi) + log(Hbs) - Hbs*(bs-mbs).^2);
lp = LogNormPdf(bs, mbs, Hbs);
end


function lp = LogNormPdf(bs, mbs, Hbs)
lp = 0.5*( - log(2*pi) + log(Hbs) - Hbs*(bs-mbs).^2);
end









