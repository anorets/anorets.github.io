This code produces estimation results in Section 6 of "Optimal auxiliary priors and reversible jump proposals
for a class of variable dimension models", by Andriy Norets

The main script is called normregression.m


