%returns logarithm of the determinant of matrix A computed using Cholesky decomposition 
function res = logdet(A) 
res = 2*sum(log(diag(chol(A))));