% This program implements a posterior simulator for parameters of a finite
% beta mixture.  For algorithm description, see
% "MCMC estimation of a finite beta mixture" by Norets and Tang

% clear all;

% set a seed for random number generator so that the results can be
% replicated
r_n_gen=RandStream('mt19937ar');
RandStream.setDefaultStream(r_n_gen);
reset(r_n_gen, 123456789); % the second parameter is a seed
% For older versions of Matlab use next line instead of the 3 prev. lines
% rg_seed_set = betarnd(1, 1, 1, 107);

% a difffuse prior for posteior estimation
N1m_ = 2; % hyperparameter for prior of m_j
N0m_ = 2; % hyperparameter for prior of m_j
As_ = 3;  % hyperparameter for prior of s_j
Bs_ = 10^2; % hyperparameter for prior of s_j
Na_ = 3; % hyperparameter for prior of lambda

% Set estimation parametrs
JDtestFlag = 0; % 0 - estimation, 1 - Geweke's joint distribution test
Niter = 100000; % number of MCMC draws
progress_step = 1000; % print # iteration, time lapsed, # accepted draws at every progress_step iteration
save_step = 1000; % save workspace every save_step iteration
thin_step = 1; % use every thin_step^{th} draw
MHRW_flag = 0; % 1 - MHRW, 0 - MOM based independence chain

% Generate dgp parameters from prior
% dgp_m = betarnd(N1m_, N0m_, 1, 3);
% dgp_s = gamrnd(As_, Bs_, 1, 3);
% dgp_lambda = gamrnd(Na_*ones(1,3), ones(1,3));  dgp_lambda =  dgp_lambda./sum(dgp_lambda,2); % Dirichlet draw
% Or set dgp values 
dgp_m = [0.2, 0.7, 0.9];
dgp_s = [10, 20, 30];
dgp_lambda = [0.8, 0.1, 0.1];
J = length(dgp_m);  % number of mixture components  
K = J*100; % sample size
% Uncomment to plot dgp density
figure(1+(1-MHRW_flag)*(3*J+2))
x = 0.001:0.001:1;
y = dgp_lambda*betapdf(repmat(x,3,1), repmat(dgp_m'.*dgp_s',1,length(x)), repmat((1-dgp_m').*dgp_s',1,length(x)));
plot(x, y);

% generate latent vars
dgp_mult_draw = mnrnd(1,dgp_lambda',K)';
[dgp_z, col] = find(dgp_mult_draw);
if J == 1
    dgp_z = dgp_z';
end
dgp_N1 = dgp_m .* dgp_s;
dgp_N0 = (1-dgp_m) .* dgp_s;
%generate data
data_p = betarnd(dgp_N1(dgp_z'), dgp_N0(dgp_z'));

% Run posterior simulator
%[Series] = postsimbetamix(J, data_p, N1m_, N0m_, As_ ,Bs_ ,Na_, JDtestFlag, MHRW_flag, Niter, progress_step ,save_step, thin_step);

Series = rand(3*J,Niter/thin_step);

burnin = length(Series(1,:))*0.1;% discard first burnin draws
filter = burnin:1:length(Series(1,:)); % defines indices of draws that will be used for plotting figures, etc.

% Uncomment for trace plots of the simulated parameters
for i = 1:3*J
    figure(1+i+(1-MHRW_flag)*(3*J+2));
    plot(Series(i,filter));
   %expect1(zeros(1,length(filter)), Series(i,filter)) 
end

% Because of label switching convergence should be evaluated at statistics
% that are invariant too label switching 
perm_inv_stat1 = max(Series(1:J,filter));
%[MEAN,STD,NSE,RNE] = expect1(zeros(1,length(filter)), perm_inv_stat1); %
%use BACC command for estimating nse and rne
%RNE1_bacc = RNE(3);
RNE1_bmse100 =  ( std(perm_inv_stat1).^2 ./ length(perm_inv_stat1)) ./ ( bmse(perm_inv_stat1,100).^2 );
RNE1_bmse1000 =  ( std(perm_inv_stat1).^2 ./ length(perm_inv_stat1)) ./ ( bmse(perm_inv_stat1,1000).^2 );

perm_inv_stat2 = max(Series(J+1:2*J,filter));
%[MEAN,STD,NSE,RNE] = expect1(zeros(1,length(filter)), perm_inv_stat2);
%RNE2_bacc = RNE(3);
RNE2_bmse100 =  ( std(perm_inv_stat2).^2 ./ length(perm_inv_stat2)) ./ ( bmse(perm_inv_stat2,100).^2 );
RNE2_bmse1000 =  ( std(perm_inv_stat2).^2 ./ length(perm_inv_stat2)) ./ ( bmse(perm_inv_stat2,1000).^2 );

%In density estimation one might care most about predictive density:
N1 = Series(1:J,filter).* Series(J+1:2*J,filter);
N0 = (1-Series(1:J,filter)).* Series(J+1:2*J,filter);
perm_inv_stat3 = sum(Series(2*J+1:3*J,filter) .* betapdf(dgp_m(2),N1,N0), 1);
%[MEAN,STD,NSE,RNE] = expect1(zeros(1,length(filter)), perm_inv_stat3);
%RNE3_bacc = RNE(3);
RNE3_bmse100 =  ( std(perm_inv_stat3).^2 ./ length(perm_inv_stat3)) ./ ( bmse(perm_inv_stat3,100).^2 )
RNE3_bmse1000 =  ( std(perm_inv_stat3).^2 ./ length(perm_inv_stat3)) ./ ( bmse(perm_inv_stat3,1000).^2 )

figure(3*J+1+(1-MHRW_flag)*(3*J+2))
plot(perm_inv_stat3);
figure(3*J+2+(1-MHRW_flag)*(3*J+2))
[y x] = ksdensity(perm_inv_stat3); 
plot(x,y,'k--'); hold on;
