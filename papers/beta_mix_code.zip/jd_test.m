% This program implements Geweke's joint distribution tests (JDT) 
% for finite beta mixture MCMC algorithm.  For a description of the
% algorithm and notation see
% "MCMC estimation of a finite beta mixture" by Norets and Tang

clear all;

JDtestFlag = 1;% flag value 1 means postsimbetamix function will also generate artificial data at every MCMC iteration
% thus the simulator gives MCMC draws from prior, see Geweke's "Getting it right: ..." in JASA

% tighter prior and small dataset for JDT
N1m_ = 20;% hyperparameter for prior of m_j
N0m_ = 20;% hyperparameter for prior of m_j
As_ = 100;% hyperparameter for prior of s_j
Bs_ = 1;% hyperparameter for prior of s_j
Na_ = 30;% hyperparameter for prior of lambda
dgp_m = [0.5, 0.5, 0.5];%0.8;%
dgp_s = [100, 100, 100];%100;%
dgp_lambda = [0.2, 0.3, 0.5];%1;%
J = length(dgp_m);   % number of mixture components    
K = J*5; % sample size should be small in JDT test to improve chain mixing

% Set estimation parametrs
Niter = 100000; % number of MCMC draws
progress_step = 1000; % print # iteration, time lapsed, # accepted draws at every progress_step iteration
save_step = 10000; % save workspace every save_step iteration
thin_step = 10; % keep only every thin_step^{th} draw
MHRW_flag = 0; % 1 - MHRW, 0 - MOM based independence chain

% generate artificial data for sampler initialization
dgp_mult_draw = mnrnd(1,dgp_lambda',K)';
[dgp_z, col] = find(dgp_mult_draw);
if J == 1
    dgp_z = dgp_z';
end
sample_sz = sum(dgp_mult_draw,2);
dgp_N1 = dgp_m .* dgp_s;
dgp_N0 = (1-dgp_m) .* dgp_s;
data_p = betarnd(dgp_N1(dgp_z'), dgp_N0(dgp_z'));

% Run posterior simulator together with data simulator (JDtestFlag=1)
[Series] = postsimbetamix(J, data_p, N1m_, N0m_, As_ ,Bs_ ,Na_, JDtestFlag, MHRW_flag, Niter, progress_step ,save_step, thin_step);

burnin = length(Series(1,:))*0.1; % discard first burnin draws
filter = burnin:1:length(Series(1,:)); % defines indices of draws that will be used for plotting figures, etc.

% Uncomment for trace plots of the simulated parameters
%for i = 1:3*J
%     figure(3+i);
%     plot(Series(i,filter));
%    expect1(zeros(1,length(filter)), Series(i,filter)) 
%end

figure(1) % figure and test for m
for j = 1:J
    [y x] = ksdensity(Series(j,filter),'support', [0 1]); 
    plot(x,y,'k--'); hold on;
end
y = betapdf(x,N1m_,N0m_);
plot(x,y,'k-'); hold on;
%t test for mean equality
for j = 1:J
    t_stat = (mean(Series(j,filter)) - N1m_./(N1m_+N0m_)) ./ bmse(Series(j,filter),100)
end

figure(2)%figure and test for s
for j = 1:J
    [y x] = ksdensity(Series(J+j,filter),'support', 'positive'); 
    plot(x,y,'k--'); hold on;
end
y = gampdf(x,As_,Bs_);
plot(x,y,'k-'); hold on;
for j = J+1:2*J  %t test for mean equality
    t_stat = (mean(Series(j,filter)) - As_* Bs_) ./ bmse(Series(j,filter),100)
end

figure(3)%figure and test for lambda
for j = 1:J
    [y x] = ksdensity(Series(2*J+j,filter),'support', [0 1]); 
    plot(x,y,'k--'); hold on;
end
prior_lambda = gamrnd(Na_*ones(10000,3), ones(10000,3));  prior_lambda =  prior_lambda./repmat(sum(prior_lambda,2),1,3); % Dirichlet draw
[y x] = ksdensity(prior_lambda(:,1),'support', 'positive'); % 'width', .01);
plot(x,y,'k-'); hold on;  

 
