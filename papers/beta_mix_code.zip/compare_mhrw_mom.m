% This script implements a Monte Carlo study from
% "MCMC estimation of a finite beta mixture" by Norets and Tang
% that compares Metropolis-Hastings independence chain based on method of moments (MOM) estimator 
% and Metropolis-Hastings random walk for simulation of parameters of beta in a finite beta mixture model
 

clear all;
% set a seed for random number generator so that the results can be
% replicated

% r_n_gen=RandStream('mt19937ar');
% RandStream.setDefaultStream(r_n_gen);
% reset(r_n_gen, 12345678); % the second parameter is a seed
% For older versions of Matlab use next line instead of the 3 prev. lines
rg_seed_set = betarnd(1, 1, 1, 107);

% a difffuse prior for posteior estimation
N1m_ = 2;
N0m_ = 2;
As_ = 3;
Bs_ = 10^2;
Na_ = 3;

% Set estimation parametrs
JDtestFlag = 0; % 0 - estimation, 1 - Geweke's joint distribution test
Niter = 100000;
progress_step = 1000; save_step = 1000; thin_step = 1;

Ncomparisons = 20;
tic

perm_inv_stat3MOM = zeros(Ncomparisons, 0.9*Niter/100);
perm_inv_stat3RW = zeros(Ncomparisons, 0.9*Niter/100);

for i = 1:Ncomparisons
% so that every iteration can be replicated  separately reinitialize random number generator    
%    reset(r_n_gen, i+20); 

    % Generate dgp parameters from prior
    dgp_m = betarnd(N1m_, N0m_, 1, 3);
    dgp_s = gamrnd(As_, Bs_, 1, 3);
    dgp_lambda = gamrnd(Na_*ones(1,3), ones(1,3));  dgp_lambda =  dgp_lambda./sum(dgp_lambda,2); % Dirichlet draw
    J = length(dgp_m);  % number of mixture components  
    K = J*100; % sample size
    % Uncomment to plot dgp density
    % figure(1+(1-MHRW_flag)*(3*J+2))
    % x = 0.001:0.001:1;
    % y = dgp_lambda*betapdf(repmat(x,3,1), repmat(dgp_m'.*dgp_s',1,length(x)), repmat((1-dgp_m').*dgp_s',1,length(x)));
    % plot(x, y);
    % draw latent variables that describe allocation of observations into mixture components
    dgp_mult_draw = mnrnd(1,dgp_lambda',K)';
    [dgp_z, col] = find(dgp_mult_draw);
    if J == 1
        dgp_z = dgp_z';
    end
    % generate data
    dgp_N1 = dgp_m .* dgp_s;
    dgp_N0 = (1-dgp_m) .* dgp_s;
    data_p = betarnd(dgp_N1(dgp_z'), dgp_N0(dgp_z'));

    % Run posterior simulators
    MHRW_flag = 1; % use MHRW algorithm
    SeriesRW = postsimbetamix(J, data_p, N1m_, N0m_, As_ ,Bs_ ,Na_, JDtestFlag, MHRW_flag, Niter, progress_step ,save_step, thin_step);
    MHRW_flag = 0; % use MOM algorithm
    SeriesMOM = postsimbetamix(J, data_p, N1m_, N0m_, As_ ,Bs_ ,Na_, JDtestFlag, MHRW_flag, Niter, progress_step ,save_step, thin_step);

    
    burnin = length(SeriesRW(1,:))*0.1+1;
    filter = burnin:1:length(SeriesRW(1,:));

    % To avoid label switching problems use statistics invariant too label switching 
    perm_inv_stat1 = max(SeriesRW(1:J,filter));
    RNE1_bmse100 =  ( std(perm_inv_stat1).^2 ./ length(perm_inv_stat1)) ./ ( bmse(perm_inv_stat1,100).^2 );
    RNE1_bmse1000 =  ( std(perm_inv_stat1).^2 ./ length(perm_inv_stat1)) ./ ( bmse(perm_inv_stat1,1000).^2 );
    perm_inv_stat2 = max(SeriesRW(J+1:2*J,filter));
    RNE2_bmse100 =  ( std(perm_inv_stat2).^2 ./ length(perm_inv_stat2)) ./ ( bmse(perm_inv_stat2,100).^2 );
    RNE2_bmse1000 =  ( std(perm_inv_stat2).^2 ./ length(perm_inv_stat2)) ./ ( bmse(perm_inv_stat2,1000).^2 );
    %In density estimation one might care most about predictive density:
    N1 = SeriesRW(1:J,filter).* SeriesRW(J+1:2*J,filter);
    N0 = (1-SeriesRW(1:J,filter)).* SeriesRW(J+1:2*J,filter);
    perm_inv_stat3 = sum(SeriesRW(2*J+1:3*J,filter) .* betapdf(dgp_m(2),N1,N0), 1);
    RNE3_bmse100 =  ( std(perm_inv_stat3).^2 ./ length(perm_inv_stat3)) ./ ( bmse(perm_inv_stat3,100).^2 );
    RNE3_bmse1000 =  ( std(perm_inv_stat3).^2 ./ length(perm_inv_stat3)) ./ ( bmse(perm_inv_stat3,1000).^2 );
    RNE_MHRW(:, i) =  [ RNE1_bmse100, RNE1_bmse1000, RNE2_bmse100, RNE2_bmse1000,RNE3_bmse100, RNE3_bmse1000]';
    perm_inv_stat3RW(i,:) = perm_inv_stat3(1:100:length(perm_inv_stat3));    
    
    perm_inv_stat1 = max(SeriesMOM(1:J,filter));
    RNE1_bmse100 =  ( std(perm_inv_stat1).^2 ./ length(perm_inv_stat1)) ./ ( bmse(perm_inv_stat1,100).^2 );
    RNE1_bmse1000 =  ( std(perm_inv_stat1).^2 ./ length(perm_inv_stat1)) ./ ( bmse(perm_inv_stat1,1000).^2 );
    perm_inv_stat2 = max(SeriesMOM(J+1:2*J,filter));
    RNE2_bmse100 =  ( std(perm_inv_stat2).^2 ./ length(perm_inv_stat2)) ./ ( bmse(perm_inv_stat2,100).^2 );
    RNE2_bmse1000 =  ( std(perm_inv_stat2).^2 ./ length(perm_inv_stat2)) ./ ( bmse(perm_inv_stat2,1000).^2 );
    N1 = SeriesMOM(1:J,filter).* SeriesMOM(J+1:2*J,filter);
    N0 = (1-SeriesMOM(1:J,filter)).* SeriesMOM(J+1:2*J,filter);
    perm_inv_stat3 = sum(SeriesMOM(2*J+1:3*J,filter) .* betapdf(dgp_m(2),N1,N0), 1);
    RNE3_bmse100 =  ( std(perm_inv_stat3).^2 ./ length(perm_inv_stat3)) ./ ( bmse(perm_inv_stat3,100).^2 );
    RNE3_bmse1000 =  ( std(perm_inv_stat3).^2 ./ length(perm_inv_stat3)) ./ ( bmse(perm_inv_stat3,1000).^2 );
    RNE_MOM(:, i) =  [RNE1_bmse100, RNE1_bmse1000, RNE2_bmse100, RNE2_bmse1000, RNE3_bmse100, RNE3_bmse1000]';
    perm_inv_stat3MOM(i,:) = perm_inv_stat3(1:100:length(perm_inv_stat3));    

	disp(sprintf('Comp n. = %d Time = %d ', i, toc));
 
	save curr_res101.mat; 
	%save('/home/anorets/betamix/job3/curr_res101.mat');
end

RNE_MOM_RW = RNE_MOM ./ RNE_MHRW;

% for i = 1:1
% 	[y x] = ksdensity(perm_inv_stat3RW(i,:),'support', 'positive'); 
%     plot(x,y,'k--'); hold on;
%     [y x] = ksdensity(perm_inv_stat3MOM(i,:),'support', 'positive'); 
%     plot(x,y,'k-'); hold on;
% end
% 
% figure(2)
% plot(perm_inv_stat3RW(1,:),'k-'); hold on;
% figure(3)
% plot(perm_inv_stat3MOM(1,:),'k-'); hold on;

% combine results from several experiments (if ran on miltiple computer nodes):
% clear all;
% COMB_RNE_MOM_RW = [];
% for j = 1:8
%     load(sprintf('C:/work/mcmcbetamix/code/experiment3/curr_res10%d.mat',j));
%     COMB_RNE_MOM_RW = [COMB_RNE_MOM_RW, RNE_MOM ./ RNE_MHRW];
% end
% filter = 1:100;
% clear a;
% for j = 1:6
%     a(j, 1) = sum( COMB_RNE_MOM_RW(j,filter) < 1) ./ length(COMB_RNE_MOM_RW(6,filter));
%     a(j, 2) = sum( COMB_RNE_MOM_RW(j,filter) >= 1 & COMB_RNE_MOM_RW(j,filter) < 2) ./ length(COMB_RNE_MOM_RW(6,filter));
% 	a(j, 3) = sum( COMB_RNE_MOM_RW(j,filter) >= 2 & COMB_RNE_MOM_RW(j,filter) < 5) ./ length(COMB_RNE_MOM_RW(6,filter));
%     a(j, 4) = sum( COMB_RNE_MOM_RW(j,filter) >= 5) ./ length(COMB_RNE_MOM_RW(6,filter));
%     a(j,:)
%     sum(a(j, :))
% end
