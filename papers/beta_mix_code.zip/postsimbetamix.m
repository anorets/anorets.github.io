% This function implements a posterior simulator for parameters of a finite beta mixture.  
% Either Metropolis-Hastings transition densities for parameters of beta are constructed 
% from the method of moments estimator or MHRW is used instead.  For algorithm description and notation see
% "MCMC estimation of a finite beta mixture" by Norets and Tang
% Function input parameters
% J, number of mixture components
% data_p, 1xK vector containing observations 
% N1m_, N0m_, beta prior hyperparameters for m_j
% As_ ,Bs_ , gamma prior hyperparameters for s_j
% Na_, dirichlet prior hyperparameters for lambda
% JDtestFlag, =1 if Geweke's joint distribution tests are performed, =0 for posterior simulation
% MHRW_flag, =1 use random walk for m and s, =0 use independence chain with MOM proposals
% Niter, number of draws
% progress_step, algorithm outputs current info at every progress_step^{th} iteration
% save_step, algorithm saves workspace at every save_step^{th} iteration
% thin_step, algorithm keeps only draws from every thin_step^{th} iteration
% Output: columns of Series contain [m,s,lambda] draws

%clear all;
function [Series] = postsimbetamix(J, data_p, N1m_, N0m_, As_ ,Bs_ ,Na_, JDtestFlag, MHRW_flag, Niter, progress_step ,save_step, thin_step)

K = length(data_p);
%Initialize the sampler
lambda = ones(1,J) ./ J;
mult_draw = mnrnd(1,lambda,K)';
[z, col] = find(mult_draw);
if J == 1
    z = z';
end
sample_sz = sum(mult_draw,2);
sum_log_pi = mult_draw * log(data_p');
sum_log_1_pi = mult_draw * log(1-data_p');
% m and s from method of moments

[m, N1m, N0m] = vec_beta_m_proposal_param(data_p, mult_draw, 1, []);
[s, As, Bs] = vec_beta_s_proposal_param(data_p, mult_draw, 1, m);

%allocate memory for the simulator output
Series  = zeros(3*J,Niter/thin_step);

m_prev = m;
s_prev = s;

accept_count = zeros(J,2);

% Parameters for MHRW, they will be tuned automatically in the first 10% of
% iterations to achieve 50% acceptance rate on average
mhrwvar_m = 0.05; mhrwvar_s = 0.35;

% Parameter that multiply the variance of the proposal distribution
mom_sv_scale = ones(J,1);
mom_mv_scale = ones(J,1);

tic;

for iter = 1:Niter; 
    
    %update quantities for generation of m and s that depend on z
    
    sample_sz = sum(mult_draw,2);

    % if there are mixture components with no data in them (sample_size = 0), 
    % m and s for them will be later drawn from prior   
    non0ind = sample_sz > 0;
    Jnon0 = sum(non0ind);
    if Jnon0 < J
        mult_draw(~non0ind,:) = []; %delete components corresponding to no observations
        sample_sz(~non0ind,:) = [];
     %   m_prev_full = m_prev;
        m_prev(~non0ind) = [];
    %    s_prev_full = s_prev;
        s_prev(~non0ind) = []; %delete components corresponding to no observations
    end
    
    sum_log_pi = mult_draw * log(data_p');
    sum_log_1_pi = mult_draw * log(1-data_p'); 

% draw m    
    s = s_prev;
    if (MHRW_flag)
        fm = normrnd( -log(1./m_prev - 1),  mhrwvar_m*ones(length(m_prev),1) );
        m = 1 ./ (1 + exp(-fm));
        log_acc_prob_m = sample_sz .* ( gammaln(s.*m_prev) - gammaln(s.*m) + gammaln(s.*(1-m_prev)) - gammaln(s.*(1-m))) ...
           + (m-m_prev).*s.*sum_log_pi + (m_prev - m).*s.*sum_log_1_pi ...
           + (N1m_-1).*log(m./m_prev) + (N0m_-1).*log((1-m)./(1-m_prev)) ...
           - ( log(m_prev.*(1-m_prev)) -  log(m.*(1-m)) );
    else
        [m1, N1m, N0m] = vec_beta_m_proposal_param(data_p, mult_draw, mom_mv_scale(non0ind,1), s_prev);
        m = betarnd(N1m+(N1m_-1), N0m+(N0m_-1));
        log_acc_prob_m = sample_sz .* ( gammaln(s.*m_prev) - gammaln(s.*m) + gammaln(s.*(1-m_prev)) - gammaln(s.*(1-m))) ...
        + (m-m_prev).*s.*sum_log_pi + (m_prev - m).*s.*sum_log_1_pi ...
        - (N1m-1).*log(m./m_prev) - (N0m-1).*log((1-m)./(1-m_prev));
    end
    
    acc_ind_m = unifrnd(0,1,Jnon0,1) < exp(log_acc_prob_m);
    accept_count(non0ind,1) = accept_count(non0ind,1) + acc_ind_m;
    m(~acc_ind_m,1) = m_prev(~acc_ind_m,1);
    %m_prev(acc_ind_m,1) = m(acc_ind_m,1);

 %draw s   
    if (MHRW_flag)
        s = exp(normrnd(log(s_prev), mhrwvar_s*ones(length(s_prev),1)));
        log_acc_prob_s = sample_sz .* ( gammaln(s) - gammaln(s_prev) + gammaln(s_prev.*m) - gammaln(s.*m) + gammaln(s_prev.*(1-m)) - gammaln(s.*(1-m))) ...
             + m.*(s-s_prev).*sum_log_pi + (1 - m).*(s-s_prev).*sum_log_1_pi ...
             + ((As_-1).*log(s./s_prev) - (s-s_prev)./Bs_ ) ...
             - log(s_prev./s);
    else   
        [s1, As, Bs] = vec_beta_s_proposal_param(data_p, mult_draw, mom_sv_scale(non0ind,1), m);
        s = gamrnd(As+(As_-1), 1./(1./Bs+1./Bs_));
        log_acc_prob_s = sample_sz .* ( gammaln(s) - gammaln(s_prev) + gammaln(s_prev.*m) - gammaln(s.*m) + gammaln(s_prev.*(1-m)) - gammaln(s.*(1-m))) ...
             + m.*(s-s_prev).*sum_log_pi + (1 - m).*(s-s_prev).*sum_log_1_pi ...
             - ((As-1).*log(s./s_prev) - (s-s_prev)./Bs );
   end
   
    acc_ind_s = unifrnd(0,1,Jnon0,1) < exp(log_acc_prob_s);
    accept_count(non0ind,2) = accept_count(non0ind,2) + acc_ind_s;
    s(~acc_ind_s,1) = s_prev(~acc_ind_s,1);
    %s_prev(acc_ind_s,1) = s(acc_ind_s,1);
 
    % if there are mixture components with no data in them (sample_size = 0)
    % draw m and s for them from prior   
    if(Jnon0 < J)
        m(non0ind) = m;
        s(non0ind) = s;
        s(~non0ind) = gamrnd(As_, Bs_, J-Jnon0, 1);
        m(~non0ind) = betarnd(N1m_, N0m_,  J-Jnon0, 1);
        m_prev = m;
        s_prev = s;
    else
        m_prev(acc_ind_m,1) = m(acc_ind_m,1);
        s_prev(acc_ind_s,1) = s(acc_ind_s,1); 
    end
    
 %draw z (represented by mult_draw)
    SM = (s.*m)';
    S1_M = (s.*(1-m))';
    %compute prob for z avoiding numerical over/under flow
    log_beta_c = gammaln(s)  - gammaln(s.*m) - gammaln(s.*(1-m));
    Q = repmat(log_beta_c',K,1) + repmat(log(data_p)',1,J).*repmat(SM,K,1) + repmat(log(1-data_p)',1,J).*repmat(S1_M,K,1) + repmat(log(lambda),K,1);
    Q = Q - repmat(max(Q,[],2), 1, J); Q = exp(Q); Q = Q ./ repmat(sum(Q,2), 1, J);
    mult_draw = mnrnd(1,Q)';
    
%draw lambda (stands for alpha)
    Na = sum(mult_draw,2)' + Na_;
    lambda = gamrnd(Na , 1);  lambda =  lambda./sum(lambda); % Dirichlet draw
    
    %jd test
    if JDtestFlag    
        [z, col] = find(mult_draw);
        if J == 1
            z = z';
        end
        dgp_N1 = m .* s;
        dgp_N0 = (1-m) .* s;
        data_p = betarnd(dgp_N1(z'), dgp_N0(z'))';
    end   
    
    
    % keep the outputs
    if floor(iter/thin_step) == iter/thin_step,
       Series(:,iter/thin_step) = [m; s; lambda'];        
    end
    
    if floor(iter/progress_step) == iter/progress_step,
       disp([sprintf('Iter = %d Time = %d Accepted m s:  ', iter, toc), num2str([accept_count(:,1)', accept_count(:,2)'])]);
        %disp(sprintf('Iter = %d Time = %d Accepted m = %d s = %d', iter, toc, accept_count(1,:)));
    end
    
    if floor(iter/save_step) == iter/save_step,
%       save(sprintf('~/Matlab/Andriy/Output/Job1/Task%d.mat', TaskNum));
    end    
    if (MHRW_flag) %tune params of MHRW
        if iter < 0.1 * Niter && floor(iter/100) == iter/100 %tune mhrw params
            avg_acc_r_m = sum(accept_count(:,1)) ./ (iter*J);
            if avg_acc_r_m < 0.4
                mhrwvar_m = mhrwvar_m*0.9;
            end;
            if avg_acc_r_m > 0.6
                mhrwvar_m = mhrwvar_m / 0.9;
            end
            avg_acc_r_s = sum(accept_count(:,2)) ./ (iter*J);
            if  avg_acc_r_s < 0.4
                mhrwvar_s = mhrwvar_s*0.9;
            end
            if  avg_acc_r_s > 0.6
                mhrwvar_s = mhrwvar_s / 0.9;
            end
        end
        
    else % tune the parameter that multiplies the variance of proposal obtained from MOM if the algorithm gets stuck
         % it is useful when algorithm is initialized with arbitrary parameter values
         if iter < 0.1 * Niter && iter > 10
            ind_m = (accept_count(:,1) ./ iter) < 0.1;
            mom_mv_scale(ind_m) = 1.1 * mom_mv_scale(ind_m);
            mom_mv_scale = min([mom_mv_scale'; 4*ones(1,J)])'; % do not make scale parameter larger than 4
            ind_s = (accept_count(:,2) ./ iter) < 0.1;
            mom_sv_scale(ind_s) = 1.1 * mom_sv_scale(ind_s);
            mom_sv_scale = min([mom_sv_scale'; 4*ones(1,J)])';
        end
   end
end

