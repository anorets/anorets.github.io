Matlab functions and scripts that implement the algorithm from "MCMC estimation of a finite beta mixture" by Andriy Norets and Xun Tang.

1. Function postsimbetamix  implements the posterior simulator for parameters.

2. Script artdata_est illustrates the use of function postsimbetamix for estimation of the model from an artificially generated dataset.

3. Script jd_test uses function postsimbetamix for performing joint distribution tests for correctnes of posterior simulators, see Geweke (2004), "Getting it right:...", JASA.

4. Function bmse computes numerical standard errors by the method of batch means.

5. Function betapdfln returns log pdf of beta distribution

6. Functions vec_beta_m_proposal_param and vec_beta_s_proposal_param return the proposals for simulating parameters of beta.

7. Script compare_mhrw_mom implements the Monte carlo study from Norets and Tang (2010) that compares performnce of a random walk algorithm and method of moments based independence chain.
