function [mm_s, As, Bs] = vec_beta_s_proposal_param(data_p, mult_draw, v_scale, m)
% This function returns proposal parameters for draws from posterior for
% beta parameter s, proposals constructed from asympt. approx.
% sampling distribution of method of moments estimator

sample_sz = sum(mult_draw,2);

% estimate s given m and data_p by method of moments (equating sample and population variance with known mean)
% and construct the sampling distribution for this estimator of s
sample_p_var = mult_draw * ((data_p  - m'*mult_draw)').^2 ./ sample_sz;

% in case there is only one draw for a component j (sample_p_var(j)=0)
% set var to average var for other components
ind_zero_var = (sample_p_var == 0); 
sample_p_var(ind_zero_var) = ones(size(sample_p_var(ind_zero_var)))*mean(sample_p_var(~ind_zero_var));

mm_s = m.* (1-m) ./ (sample_p_var) - 1;
sample_p_kurtosis = mult_draw * ((data_p  - m'*mult_draw)').^4 ./ sample_sz;
var_sample_p_var = (sample_p_kurtosis - sample_p_var.^2) ./ sample_sz;
var_mm_s = v_scale .* var_sample_p_var .* (m.^2 .* (1-m).^2) ./ (sample_p_var.^4);

Bs = var_mm_s  ./ mm_s;
As = mm_s.^2 ./ var_mm_s;

% plot normal and gamma asymptotic approximations  and  posterior normalized to match the height of the approximation.
% close all
% for j = 1:length(m)
%     s_grid =  mm_s(j) - 5*sqrt(var_mm_s(j)) : sqrt(var_mm_s(j))./ 10 : mm_s(j)+5*sqrt(var_mm_s(j));
%     m_grid = m(j) * ones(1, length(s_grid));
%     N1 = m_grid .* s_grid;
%     N0 = (1-m_grid) .* s_grid;
%     [z, col] = find(mult_draw);
%     p_j = data_p(z==j);
%     unnorm_post = sum(betapdfln( repmat(p_j, length(s_grid),1), repmat(N1',1, length(p_j)), repmat(N0',1, length(p_j))), 2);
%     unnorm_post = unnorm_post - max(unnorm_post);
%     s_gamma_aprox = gampdf(s_grid,As(j),Bs(j));
%     s_norm_aprox = normpdf(s_grid, mm_s(j), sqrt(var_mm_s(j)));
%     unnorm_post = exp(unnorm_post)*max(s_norm_aprox);
%     figure(j);
%     plot(s_grid, s_gamma_aprox, '--'); hold on;
%     plot(s_grid, s_norm_aprox, '-.'); hold on;
%     plot(s_grid, unnorm_post, '-'); hold on;
% end