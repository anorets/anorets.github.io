function [mm_m, N1m, N0m] = vec_beta_m_proposal_param(data_p, mult_draw, v_scale, s)
% This function returns proposal parameters for draws from posterior for
% beta parameter m, proposal constructed from asympt. approx.
% sampling distribution of method of moments estimator

sample_sz = sum(mult_draw,2);

%method of moments estimator for m and s, see formula on wikipedia
mm_m = (mult_draw*data_p') ./ sample_sz;
p_v = mult_draw * ((data_p  - mm_m'*mult_draw)').^2 ./ sample_sz;
%asymptotic variance for method of moments estimator
mm_v_m = v_scale .* p_v ./ sample_sz;

% in case there is only one draw for a component j (p_v(j)=0)
ind_zero_var = (mm_v_m == 0); 
mm_v_m(ind_zero_var) = 0.5*mm_m(ind_zero_var).*(1-mm_m(ind_zero_var));

%For m find parameters of Beta that would deliver sampling distribution 
% mean and variance for method of moments estimator
N1m = mm_m.*(mm_m.*(1-mm_m)./ mm_v_m - 1);
N0m = (1-mm_m).*(mm_m.*(1-mm_m)./ mm_v_m - 1);

% plot normal and beta asymptotic approximations  and  posterior normalized to match the height of the approximation.
% close all
% for j = 1:length(s)
%     m_grid =  mm_m(j) - 5*sqrt(mm_v_m(j)) : sqrt(mm_v_m(j))./ 10 : mm_m(j)+5*sqrt(mm_v_m(j));
%     s_grid = s(j) * ones(1, length(m_grid));
%     N1 = m_grid .* s_grid;
%     N0 = (1-m_grid) .* s_grid;
%     [z, col] = find(mult_draw);
%     p_j = data_p(z==j);
%     unnorm_post = sum(betapdfln( repmat(p_j, length(s_grid),1), repmat(N1',1, length(p_j)), repmat(N0',1, length(p_j))), 2);
%     unnorm_post = unnorm_post - max(unnorm_post);
%     m_beta_aprox = betapdf(m_grid, N1m(j), N0m(j));
%     m_norm_aprox = normpdf(m_grid, mm_m(j), sqrt(mm_v_m(j)));
%     unnorm_post = exp(unnorm_post)*max(m_norm_aprox);
%     figure(j);
%     plot(m_grid, m_beta_aprox, '--'); hold on;
%     plot(m_grid, m_norm_aprox, '-.'); hold on;
%     plot(m_grid, unnorm_post, '-'); hold on;
% end