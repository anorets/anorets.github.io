function logpdf = betapdfln(X, A, B)
% This function returns log of beta pdf 

logpdf = (A-1).*log(X) + (B-1).*log(1-X) - betaln(A, B);
