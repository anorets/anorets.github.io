function [lpdf, Jlpdf, Hlpdf] = Ptildeyy_given_param(y, n, d, mu, alphaunn, hy, nuy, m, CalcDerivFlag)
%Compute log p(y,y^\ast|\theta_{1m},m) and it 1st and 2nd derivatives wrt \theta_m

alpha = alphaunn./sum(alphaunn);
nuyhy = nuy.*hy;

Qy = bsxfun(@minus, repmat(y',1,m), reshape(mu,1,m*d));
Qy = bsxfun(@times, Qy.^2, reshape(nuyhy,1,m*d));
SQy = reshape(sum(reshape(Qy',d,m*n),1), m, n)';
SQy = -0.5*(SQy-sum(log(nuyhy),1)+d*log(2*pi)) + log(alpha');%log(\alpha_j p_{ij})

%avoiding numerical over/under flow
maxlajpij = max(SQy,[],2);
Q = exp(SQy - repmat(maxlajpij, 1, m));
sumQ = sum(Q,2);
lpdf = sum(maxlajpij+log(sumQ));
    
if CalcDerivFlag
    %Compute Jacobian wrt (mu(:,m),nu(:,m),alphaunn(m))
    w = Q(:,m)./sumQ; 
    y_mum = (y - mu(:,m));
    y_mum_nuh = y_mum.*nuyhy(:,m);
    Jlpdf = zeros(2*d+1,1);
    Jlpdf(1:d,1) = y_mum_nuh * w;
    nuyminv_hyty_mum2t05 = 0.5*(1./nuy(:,m)-hy.*y_mum.^2);
    Jlpdf(d+1:2*d,1) = nuyminv_hyty_mum2t05 * w;
    sumw = sum(w);
    Jlpdf(2*d+1,1) = sumw./alphaunn(m)-n./sum(alphaunn);
    
    %Compute Hessian wrt (mu(:,m),nu(:,m),alphaunn(m))
    w1_w = w.*(1-w);
    Hlpdf = zeros(2*d+1,2*d+1);
    Hlpdf(1:d,1:d) = -sumw*diag(hy.*nuy(:,m))+sum(bsxfun(@times,xxtvec(y_mum_nuh'), reshape(w1_w,1,1,n)),3);
    Hlpdf(d+1:2*d,d+1:2*d) = -0.5*sumw*diag(1./nuy(:,m).^2) + sum(bsxfun(@times,xxtvec(nuyminv_hyty_mum2t05'), reshape(w1_w,1,1,n)),3);
    Hlpdf(2*d+1,2*d+1) = n./(sum(alphaunn).^2) - sum(w.^2)./(alphaunn(m).^2);
    
    Hlpdf(1:d,d+1:2*d) = diag((y_mum.*hy)*w) + sum(bsxfun(@times,yxtvec(y_mum_nuh',nuyminv_hyty_mum2t05'), reshape(w1_w,1,1,n)),3);
    Hlpdf(d+1:2*d, 1:d) = Hlpdf(1:d,d+1:2*d)';
    Hlpdf(2*d+1, 1:d) = (y_mum_nuh * w1_w)'./alphaunn(m);
    Hlpdf(1:d, 2*d+1) = Hlpdf(2*d+1, 1:d)';
    Hlpdf(2*d+1, d+1:2*d) = (nuyminv_hyty_mum2t05 * w1_w)'./alphaunn(m);
    Hlpdf(d+1:2*d, 2*d+1) = Hlpdf(2*d+1, d+1:2*d)';
else
     Jlpdf = [];
     Hlpdf = [];
end
%     d2dmu_12 = -nuyhy(1,m)*sumw +sum(w1_w'.*(y_mum_nuh(1,:).^2));
%     stop = 1;
    
    
    
    
    
    