%Use this function in Newton method to transform Hessian  when it is not negative definite
function A = Negadefinize(B)

%old code
% if ~issymmetric(B)
%     B = (B+ B')./2;
% end
% B = B - eye(size(B)).*10^-4;
% if min(eig(-B))<0 
%     dB = abs(diag(B));
%     A = -diag(dB + max(dB,10^-6*ones(size(dB)))); 
% else
%     A = B;
% end
%old code

[T,err] = cholcov(-B);
if err ~= 0
    if ~issymmetric(B)
        B = (B+ B')./2;
    end
    B = B - eye(size(B)).*10^-4;
    if min(eig(-B))<0 
        dB = abs(diag(B));
        A = -0.5*diag(dB + max(dB,10^-4*ones(size(dB)))); 
    else
        A = B;
    end
else
    A=B;
end