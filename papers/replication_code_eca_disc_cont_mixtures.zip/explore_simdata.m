
load('ts_master.mat')

recoded_ts = ts_master(:,1)*10^4+ts_master(:,2)*10^2+ts_master(:,3)*10+ts_master(:,4);
recoded_tab = tabulate(recoded_ts);
non0ind = find(recoded_tab(:,2));
recoded_tabnon0 = recoded_tab(non0ind,:);
sum(recoded_tabnon0(:,3))

%draw a random sample from the population in recoded_tabnon0
n = 500;
mult_draw = mnrnd(1,recoded_tabnon0(:,3)./100,n)'; 
[s, ~] = find(mult_draw);
recoded_sample = recoded_tabnon0(s,1);

recoded_sample_tab = tabulate(recoded_sample);
non0indsample = find(recoded_sample_tab(:,2));
recoded_sample_tabnon0 = recoded_sample_tab(non0indsample,:);

sum(recoded_sample_tabnon0(:,3)./100)

N = length(recoded_tabnon0(:,1));
estimated_prob = zeros(N,1);


tsumm = 0;
for i=1:length(recoded_sample_tabnon0(:,1))
    ind = find(recoded_sample_tabnon0(i,1) == recoded_tabnon0(:,1));
    estimated_prob(ind) = recoded_sample_tabnon0(i,3)./100;
    tsumm = tsumm + recoded_sample_tabnon0(i,3);%./100;
end


estimated_exact_prob = [estimated_prob, recoded_tabnon0(:,3)./100];
sum(estimated_exact_prob)


sum(abs(estimated_exact_prob(:,1)-estimated_exact_prob(:,2)))



% create data for estimation by mixtures
clear y;
y(1,:) = floor(recoded_sample(:,1)./10^4)';
y(2,:) = floor((recoded_sample(:,1)' - y(1,:).*10^4)./10^2);
y(3,:) = floor((recoded_sample(:,1)' - y(1,:).*10^4 - y(2,:).*10^2)./10);
y(4,:) = recoded_sample(:,1)' - y(1,:).*10^4 - y(2,:).*10^2 - y(3,:).*10;
d = 4;
dd = 4;
[yda,ydb] = create_trunc_bds(y, dd);
bds = [yda; ydb];
[ymean, yvar, mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_] = EBayesDefaultPriorParams(y);

%Initialize parameters
m = 10;
mu = repmat(ymean, 1, m).*(1:m);
hy = 1./(diag(yvar));%gamrnd(Ahy_, 1./Bhy_);%hy = 1;
nuy = ones(d,m);
alphaunn = gamrnd(ones(1,m).*A_./m,1)'; alpha0=alphaunn/sum(alphaunn); 

Nsim = 10000; jdt_flag=0; progress_step = 100;

% Call posterior simulator %%%%%%%%%%%%%%%%%%%%%%%%%% 
% [sim_mu, sim_alphaunn, sim_hy, sim_nuy, sim_m] ...
%          = post_simulator_fixed_m(y, yda, ydb,...
%                             mu, alphaunn, hy, nuy, m,...
%                             mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_,...
%                             Nsim, jdt_flag, progress_step);


 [sim_mu, sim_alphaunn, sim_hy, sim_nuy, sim_m] ...
         = post_simulator_optrjmcmc(y, yda, ydb,...   %
                            mu, alphaunn, hy, nuy, m,...
                            mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_,...
                            Nsim, jdt_flag, progress_step);
                       
 plot_test_postsimout;                        
                        

clear y;
recoded_sample = recoded_tabnon0(:,1);
y(1,:) = floor(recoded_sample(:,1)./10^4)';
y(2,:) = floor((recoded_sample(:,1)' - y(1,:).*10^4)./10^2);
y(3,:) = floor((recoded_sample(:,1)' - y(1,:).*10^4 - y(2,:).*10^2)./10);
y(4,:) = recoded_sample(:,1)' - y(1,:).*10^4 - y(2,:).*10^2 - y(3,:).*10;
d = 4;
dd = 4;
[yda,ydb] = create_trunc_bds(y, dd);
n_eval = length(y(1,:));

burnin = 0.1*Nsim;
thin_step = 100;
pmdf = zeros(n_eval,length(burnin:thin_step:Nsim));
i = 1;
for sim = burnin:thin_step:Nsim
    pmdf(:,i) = Py_given_param(y, yda, ydb, n_eval, d, dd, ...
            sim_mu(:,1:sim_m(sim),sim), sim_alphaunn(1:sim_m(sim),sim), sim_hy(:,sim), sim_nuy(:,1:sim_m(sim),sim), sim_m(sim))';
    i = i+1;
end

mix_estimated_prob = mean(pmdf,2);
freq_error = sum(abs(estimated_exact_prob(:,1)-estimated_exact_prob(:,2)))
mix_error = sum(abs(mix_estimated_prob-estimated_exact_prob(:,2)))
max_freq_error = max(abs(estimated_exact_prob(:,1)-estimated_exact_prob(:,2)))
max_mix_error = max(abs(mix_estimated_prob-estimated_exact_prob(:,2)))



