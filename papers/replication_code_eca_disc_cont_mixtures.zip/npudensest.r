library(np)
#currPath = "/home/anorets/mcnew41/"
currPath = "C:/Users/anorets/Dropbox (Brown)/work/projects/smoothdiscnonp/fmmncode4eca2/"
estD<-read.table(paste(currPath,"EstDataForR.txt", sep = ""))
preD<-read.table(paste(currPath,"PredDataForR.txt", sep = ""))
yest <- data.frame(as.ordered(estD[,1]), as.ordered(estD[,2]), as.ordered(estD[,3]), as.ordered(estD[,4]))
ypre <- data.frame(as.ordered(preD[,1]), as.ordered(preD[,2]), as.ordered(preD[,3]), as.ordered(preD[,4]))
bs <- npudensbw(yest)
P <- npudens(bws=bs,tdat=yest, edat=ypre)
AA<-P$dens
write.table(AA,file=paste(currPath,"udensPredFromR.txt", sep = ""),row.names=FALSE,col.names=FALSE)
save(bs, P, file = paste(currPath,"bandwidthNP.RData", sep = ""))