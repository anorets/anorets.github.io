% MCMC update of 
% (b, mu, alphaunn, hy, hx, nuy, nux) | m 


function [theta, m, AccFlag] = mcmc_iter_m(theta, m, FixedQuants)

    AccFlag = 0;
    
    if rand < 0.5 %try to jump to m+1
%    if m < 10
        
        theta_mp1_init = theta(:,m);
%          theta_mp1_init(1:FixedQuants.d,1) = mean(FixedQuants.y,2);
%          theta_mp1_init(FixedQuants.d+1:2*FixedQuants.d,1) = 1./(diag(cov(FixedQuants.y')).*FixedQuants.hy);
%          theta_mp1_init(2*FixedQuants.d+1,1) = sum(theta(2*FixedQuants.d+1,:))./m;
        
        prop_param = FindProposalParams_mcmc_m(theta, m, theta_mp1_init, FixedQuants);
        theta_mp1 = DrawProposal_mcmc_m(prop_param);
        if ProposalInsideDomain_mcmc_m(theta_mp1,FixedQuants)
            
  
%             lklhd_improvement = LogLikelihood_mcmc_m([theta,prop_param{1}], m+1, FixedQuants) - LogLikelihood_mcmc_m(theta, m, FixedQuants);
%             
%             lk_test1 = LogLikelihood_mcmc_m([theta,[1;1;0]], m+1, FixedQuants);
%             lk_test2 = LogLikelihood_mcmc_m(theta, m, FixedQuants);
%             
%             
%             diffPrior = DiffLogPrior_mcmc_m([theta,prop_param{1}],m+1,FixedQuants);
            
            
            theta_1mp1 = [theta,theta_mp1];

            %diffLogL = LogLikelihood_mcmc_m(theta_1mp1, m+1, FixedQuants) - LogLikelihood_mcmc_m(theta, m, FixedQuants)
            
            logAccProbMp1 = LogLikelihood_mcmc_m(theta_1mp1, m+1, FixedQuants) ...
                            - LogLikelihood_mcmc_m(theta, m, FixedQuants) ...
                            - LogProposalDensity_mcmc_m(theta_mp1, prop_param) ...
                            + DiffLogPrior_mcmc_m(theta_1mp1,m+1,FixedQuants) ... 
                            + LogPrior_m_mcmc_m(m+1,FixedQuants) - LogPrior_m_mcmc_m(m,FixedQuants);

            if rand < exp(logAccProbMp1)
                theta = theta_1mp1;
                m = m+1;
                AccFlag = 1;
            end
 %       end 
    end
    else % try m-1
        if m > 1

           %prop_param = FindProposalParams_mcmc_m(theta(:,1:m-1), m-1, theta(:,m),FixedQuants);
           prop_param = FindProposalParams_mcmc_m(theta(:,1:m-1), m-1, theta(:,m-1),FixedQuants);
            
           logAccProbMm1 = LogLikelihood_mcmc_m(theta(:,1:m-1), m-1,FixedQuants) ...
                - LogLikelihood_mcmc_m(theta, m, FixedQuants) ...
                + LogProposalDensity_mcmc_m(theta(:,m), prop_param) ...
                - DiffLogPrior_mcmc_m(theta,m,FixedQuants) ... 
                + LogPrior_m_mcmc_m(m-1,FixedQuants) - LogPrior_m_mcmc_m(m,FixedQuants);

            if rand < exp(logAccProbMm1)
                theta = theta(:,1:m-1);
                m=m-1;
                AccFlag = -1;
            end
        end
    end

%% end of retrospective sampling for drawing m, %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

