function [lpdf, Jlpdf, Hlpdf] = lprior_nuy_mu_alphaunn_mJH(mu, alphaunn, nuy, m, mu_, Hmu_, A_, Anuy_, Bnuy_, derivativesFlag)
%Compute log p(\theta_m}|m) + log p(alphaunn(1:m-1)|m) and its 1st and 2nd derivatives wrt \theta_m

d = length(mu(:,1));

% lpdf = sum( (Anuy_-1).*log(nuy(:,m)) - Bnuy_.*nuy(:,m) ...
%         + 0.5*log(nuy(:,m)) - 0.5*nuy(:,m).*diag(Hmu_).*(mu(:,m)-mu_).^2 ) ...
%      +(A_./m - 1)*log(alphaunn(m)) - alphaunn(m);
 
%actually need it with normalizing constants in mcmc_iter_m!!!

lpdf = sum(lngampdf(nuy(:,m),Anuy_,Bnuy_)) + lnnormpdf(mu(:,m), mu_, diag(nuy(:,m).*diag(Hmu_))) + lngampdf(alphaunn(m),A_./m,1);
 
 if derivativesFlag
     
     Jlpdf = zeros(2*d+1,1);
     Jlpdf(1:d,1) = -nuy(:,m).*diag(Hmu_).*(mu(:,m)-mu_);
     Jlpdf(d+1:2*d,1) = (Anuy_-0.5)./nuy(:,m) - 0.5*diag(Hmu_).*(mu(:,m)-mu_).^2 - Bnuy_;
     Jlpdf(2*d+1,1) = (A_./m - 1)./alphaunn(m) - 1;
     Hlpdf = zeros(2*d+1,2*d+1);
     Hlpdf(1:d,1:d) = -diag(nuy(:,m).*diag(Hmu_));
     Hlpdf(d+1:2*d,d+1:2*d) = -diag((Anuy_-0.5)./nuy(:,m).^2);
     Hlpdf(2*d+1,2*d+1) = -(A_./m - 1)./alphaunn(m).^2;
     Hlpdf(1:d,d+1:2*d) = -diag(diag(Hmu_).*(mu(:,m)-mu_));
     Hlpdf(d+1:2*d, 1:d) = Hlpdf(1:d,d+1:2*d)';
     Hlpdf(2*d+1, 1:2*d) = zeros(1,2*d);
     Hlpdf(1:2*d,2*d+1) = zeros(2*d,1);
 else
     Jlpdf = [];
     Hlpdf = [];
 end