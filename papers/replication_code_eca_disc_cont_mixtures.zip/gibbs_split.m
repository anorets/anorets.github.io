function [split_ind, logGibbsProb, lml, N0, N1] = gibbs_split(y, Ngibs, hy, m, mu_, Hmu_, Anuy_, Bnuy_, A_, split_ind_init)

logGibbsProb = 0;
N = length(y(1,:));
d = length(y(:,1));
%k = sort_coord;%randi(d);
%[~, sort_ind] = sort(y(k,:));
%split_ind = zeros(1,N);
%split_ind(sort_ind(1:1+floor(N/10))) = 1;
%split_ind = logical(split_ind);

split_ind = logical(split_ind_init);

Sy_1 = sum(y(:,split_ind),2);
Sy2_1 = sum(y(:,split_ind).^2,2);
Sy_0 = sum(y(:,~split_ind),2);
Sy2_0 = sum(y(:,~split_ind).^2,2);
N1 = sum(split_ind);
N0 = N - N1;
lml = log_ml([Sy_1, Sy_0], [Sy2_1, Sy2_0], [N1; N0], hy, mu_, Hmu_, Anuy_, Bnuy_); 
      
for r = 1:Ngibs
   for i = 1:N
       if split_ind(i)
           sign = 1;
       else
           sign = -1;
       end
        Sy_1_sw = Sy_1 - sign*y(:,i);
        Sy2_1_sw = Sy2_1 - sign*y(:,i).^2;
        Sy_0_sw = Sy_0 + sign*y(:,i);
        Sy2_0_sw = Sy2_0 + sign*y(:,i).^2;
        N1_sw = N1 - sign;
        N0_sw = N0 + sign;
        lml_sw = log_ml([Sy_1_sw, Sy_0_sw], [Sy2_1_sw, Sy2_0_sw], [N1_sw; N0_sw], hy, mu_, Hmu_, Anuy_, Bnuy_); 
        log_p_stay = sum(lml) + log(A_./m + split_ind(i)*N1_sw+(1-split_ind(i))*N0_sw);
        log_p_sw = sum(lml_sw) + log(A_./m + split_ind(i)*N0 +(1-split_ind(i))*N1);
        p_stay = 1./(1+exp(log_p_sw-log_p_stay));
        if rand < p_stay
            logGibbsProb = logGibbsProb + log(p_stay);
        else
            split_ind(i) = ~split_ind(i);
            logGibbsProb = logGibbsProb + log(1 - p_stay);
            N1 = N1_sw;
            N0 = N0_sw;
            lml = lml_sw;
            Sy_1 = Sy_1_sw;
            Sy2_1 = Sy2_1_sw;
            Sy_0 = Sy_0_sw;
            Sy2_0 = Sy2_0_sw;
        end
   end
end





