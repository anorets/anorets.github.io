function lpdf = LogPrior_mcmc_m(theta,m, FQ)

[lpdf, ~,~] = lprior_nuy_mu_alphaunn_mJH(theta(1:FQ.d,:), theta(2*FQ.d+1,:)', theta(FQ.d+1:2*FQ.d,:), m, FQ.mu_, FQ.Hmu_, FQ.A_, FQ.Anuy_, FQ.Bnuy_, 0);

%[lpdf, ~,~] = Ptildeyy_given_param(FQ.y, FQ.n, FQ.d, theta(1:FQ.d,:), theta(d*FQ.d+1,:)', FQ.hy, theta(FQ.d+1:2*FQ.d,:), m);
