function pmdf = Py_given_param(y, yda, ydb, n, d, dd, ...
                                mu, alphaunn, hy, nuy, m)


   alpha = alphaunn./sum(alphaunn);
                            
 temp1 = repmat(ydb',1,m);
 temp2 = repmat(reshape(mu(1:dd,:),1,m*dd), n, 1);
 temp3 = repmat(reshape(1./sqrt(nuy(1:dd,:).*hy(1:dd,:)),1,m*dd), n, 1);
    
    Phi_b_a = normcdf(repmat(ydb',1,m), ...
                    repmat(reshape(mu(1:dd,:),1,m*dd), n, 1),...
                    repmat(reshape(1./sqrt(nuy(1:dd,:).*hy(1:dd,:)),1,m*dd), n, 1)) - ...
                    normcdf(repmat(yda',1,m), ...
                    repmat(reshape(mu(1:dd,:),1,m*dd), n, 1),...
                    repmat(reshape(1./sqrt(nuy(1:dd,:).*hy(1:dd,:)),1,m*dd), n, 1));
                
    %pmf = alpha'*reshape(prod(reshape(Phi_b_a',d,m*n)), m, n);
    dc = d - dd;
    if d > dd
       phi_y = normpdf(repmat(y(dd+1:d,:)',1,m), ...
                    repmat(reshape(mu(dd+1:d,:),1,m*dc), n, 1),...
                    repmat(reshape(sqrt(nuy(dd+1:d,:).*hy(dd+1:d,:)),1,m*dc), n, 1));
        
       pmdf = alpha'*(reshape(prod(reshape(phi_y',dc,m*n)), m, n).*reshape(prod(reshape(Phi_b_a',d,m*n)), m, n));
        
    else
       pmdf = alpha'*reshape(prod(reshape(Phi_b_a',dd,m*n)), m, n);
    end