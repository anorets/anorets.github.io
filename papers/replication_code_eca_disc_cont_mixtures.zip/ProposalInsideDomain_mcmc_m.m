function flag = ProposalInsideDomain_mcmc_m(theta_mp1,FixedQuants)

flag = sum(theta_mp1(FixedQuants.d+1:end) < 0) == 0 ;
