function npupdfvals = CompPredUDensNP(pred_y, flagRecalc)

if flagRecalc
    dataforRpred=pred_y';
    save 'PredDataForR.txt' dataforRpred -ascii;
%    path(path,'C:/Program Files/R/R-3.2.2/bin');
%    path(path,'C:/Program Files/R/R-3.5.1/bin/x64');
% Add path to R to system PATH
system('R CMD BATCH npudensest.r'); 
end

npupdfvals = importdata('udensPredFromR.txt');