function theta = DrawProposal_mcmc_m(prop_param)

theta = mvnrnd(prop_param{1}', inv(prop_param{2}))';

%prop_param{1} = thetamp1; 
%prop_param{2} = H; 