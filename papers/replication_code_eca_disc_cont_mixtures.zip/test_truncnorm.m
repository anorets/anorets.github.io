n = 100000;
mu = 1; sigma = 1; a = -inf; b = inf;
y = truncnormrnd(mu*ones(1,n), sigma*ones(1,n), a*ones(1,n), b*ones(1,n));
mean(y)
std(y)
sum(y<a)
sum(y>b)
[f, z] = ksdensity(y);%,'Support',[a b]);
        figure(1)
        plot(z,f); 
        hold on;
        range = xlim; z = range(1):(range(2)-range(1))./200:range(2);
        f = normpdf(z, mu, sigma)./(normcdf(b,mu,sigma)-normcdf(a,mu,sigma));
        plot(z,f,'LineStyle','--');
