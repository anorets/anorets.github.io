% x=[x1; x2; ... xn], xi=[xi1,...,xim], y(:,:,i) = xi^t xi
function y = xxtvec(x)
[n m] = size(x);
y = reshape((repmat(x,1,m).* reshape(repmat(reshape(x',n*m,1), 1,m)',m^2,n)')', m,m,n);
