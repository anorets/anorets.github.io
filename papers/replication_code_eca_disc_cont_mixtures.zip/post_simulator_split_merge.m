% Posterior simulator for the following model of y_i i =1,n:
% p(y_i) = \sum_{j=1}^m  alpha(j) * \phi(y_i,mu_j,(hy*nuy(j))^-1) 
% Observables: y_ik, k=dd+1,...,d and y_ik \in [yda(k,i),ydb(k,i)], k=1,...,dd

function [sim_mu, sim_alphaunn, sim_hy, sim_nuy, sim_m] ...
         = post_simulator_split_merge(y, yda, ydb,...
                            mu0, alphaunn0, hy0, nuy0, m0,...
                            mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_,...
                            Nsim, jdt_flag, progress_step)


% some inputs check                                                      
szy = size(y); szyda = size(yda); szydb = size(ydb);
d = szy(1);
n = szy(2);
dd = szyda(1);
% if szyda(2) ~= n || szydb(2) ~= n || szydb(1) ~= dd  
%     error('post_simulator: input dimensions do not match');
% end


mMaxInit = 20; % upper bound on m used for memory allocation before for loop, if m exceed this then more memory is allocated

hyAccCount = 0;
mp1AccCount = 0;
mm1AccCount = 0;

ind_1_n = 1:n;

sim_mu = zeros(d,mMaxInit,Nsim);
sim_alphaunn = zeros(mMaxInit,Nsim);
sim_hy = zeros(d,Nsim); 
sim_nuy = zeros(d,mMaxInit,Nsim);
sim_m = zeros(1,Nsim);
sim_md = 0;
%sum_alphaunn = zeros(1,Nsim);
currlogLikelihood = zeros(1,Nsim); 
propPlogLikelihood = zeros(1,Nsim);
propMlogLikelihood = zeros(1,Nsim);

nonconvcount = 0;

mu=mu0; alphaunn=alphaunn0; hy=hy0; nuy=nuy0; m=m0;

[s, mult_draw, N] = mcmc_iter_s_given_m_param(y, n, d, mu, alphaunn, hy, nuy, m);

tic


for sim = 1:Nsim


    
[mu, alphaunn, hy, nuy, hyAccCount] = mcmc_iter_param_given_m_s_y(y, n, d, ...
                                s, mult_draw, N,...
                                hy, m,...
                                hyAccCount, ...
                                mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_);

% store simulated params
sim_mu(:,1:m,sim) = mu;
sim_alphaunn(1:m,sim) = alphaunn;
sim_hy(:,sim) = hy; 
sim_nuy(:,1:m,sim) = nuy; 
sim_m(:,sim) = m;
     


    
 %   sim
 %   y
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

% %block for latent variables y
if dd
    muy = mu(1:dd,s); sdy = 1./sqrt(hy(1:dd,1).*nuy(1:dd,s)); y(1:dd,:) = truncnormrnd(muy,sdy,yda,ydb);                            
end    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if jdt_flag % simulate data for joint d-n tests
    [y, yda, ydb] = gen_data(n, dd, mu, alphaunn, hy, nuy, m);
end



%random label switch
mdraw = randi(m); % random label permutation - valid mcmc transition
if mdraw ~= m
    mutemp = mu(:,m); nuytemp = nuy(:,m); alphaunntemp = alphaunn(m);
    mu(:,m)=mu(:,mdraw); nuy(:,m) = nuy(:,mdraw); alphaunn(m)=alphaunn(mdraw);
    mu(:,mdraw)=mutemp; nuy(:,mdraw)=nuytemp; alphaunn(mdraw)=alphaunntemp;
end
%end random label switch

%Update s
[s, mult_draw, N] = mcmc_iter_s_given_m_param(y, n, d, mu, alphaunn, hy, nuy, m);
% 

%Update s using marginal likelihood/marginalizing over parameters tot test
% %log ML calculation
% Sy = y*mult_draw'; % (\sum_{s_i=1} y_i, ..., \sum_{s_i=m} y_i)
% Sy2 = (y.^2)*mult_draw';
% curr_lml = log_ml(Sy, Sy2, N, hy, mu_, Hmu_, Anuy_, Bnuy_);
% 
% for i=1:n
%     lml_union_y_i = log_ml(Sy+y(:,i), Sy2+y(:,i).^2, N+1, hy, mu_, Hmu_, Anuy_, Bnuy_);    
%     lml_Csi_wo_i =  log_ml(Sy(:,s(i))-y(:,i), Sy2(:,s(i))-y(:,i).^2, N(s(i))-1, hy, mu_, Hmu_, Anuy_, Bnuy_);   
% 
%     log_alloc_prob = lml_union_y_i + lml_Csi_wo_i - curr_lml - curr_lml(s(i)) + log(A_/m+N');
%     log_alloc_prob(s(i)) = log(A_/m+N(s(i))-1);
% 
%     alloc_prob = exp(log_alloc_prob - max(log_alloc_prob));
%     alloc_prob = alloc_prob./sum(alloc_prob);
% 
%     mult_draw_i = mnrnd(1,alloc_prob)';
%     [new_si, ~] = find(mult_draw_i);
%     if new_si ~= s(i)
%        curr_lml(s(i)) = lml_Csi_wo_i;
%        curr_lml(new_si) = lml_union_y_i(new_si);
%        Sy(:,s(i)) = Sy(:,s(i))-y(:,i);
%        Sy2(:,s(i)) = Sy2(:,s(i))-y(:,i).^2;
%        Sy(:,new_si) = Sy(:,new_si)+y(:,i);
%        Sy2(:,new_si) = Sy2(:,new_si)+y(:,i).^2;
%        mult_draw(s(i),i) = 0; mult_draw(new_si,i) = 1;
%        N(s(i))=N(s(i))-1; N(new_si)=N(new_si)+1;
%        s(i) = new_si;
%        
%     end
% end
%% end marginal update for s


% %Split merge block for updating m and s

[m, N, s, mult_draw, AccFlag] = mcmc_iter_sm_given_hy_sm_ver2(y, mult_draw, s, N, m, hy, mu_, Hmu_, A_, Anuy_, Bnuy_, Am_, Amlogp_,ind_1_n);
if AccFlag == 1
    mp1AccCount = mp1AccCount + 1;
elseif AccFlag == -1
    mm1AccCount = mm1AccCount + 1;
end

%End split merge block    
    
    if m > mMaxInit % then need to allocate more memory for storage
        mMaxD = 5;
        sim_mu = cat(2, sim_mu, zeros(d,mMaxD,Nsim));
        sim_alphaunn = cat(1, sim_alphaunn, zeros(mMaxD,Nsim));
        sim_nuy = cat(2, sim_nuy, zeros(d,mMaxD,Nsim));
    end

    
    %alphaunn'
    
  
    
    if floor(sim/progress_step) == sim/progress_step, % output current mcmc stats, e.g., acceptance rates
        msg = sprintf('Iter = %d Time = %d HyAccR = %d m = %d Params = %d %d %d %d', sim, toc, hyAccCount./sim, m, mu(1), alphaunn(1), hy(1), nuy(1,1));
        display(msg);
%         hy*nuy
         msg2 = sprintf('Acc Counts: mp1 = %d mm1 = %d hyAccR = %d ', mp1AccCount, mm1AccCount, hyAccCount./sim);
         display(msg2);
   
%          mu
%          nuy
%          hy
%          alphaunn
%        muAccCount
%        nuxAccCount
%        hxAccCount
%         N'
%      alphaunn
%       hyAccCount
        %plot_postsim; 
        drawnow;
    end
end

