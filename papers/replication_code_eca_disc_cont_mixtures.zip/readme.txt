This is a collection of Matlab scripts and functions for replicating the results reported in 
``Adaptive Bayesian Estimation of Mixed Discrete-Continuous Distributions under Smoothness and Sparsity'' by Norets and Pelenis.


Main files:

mc_mix_vs_freq_in_io.m - the main matlab script that performs the Monte Carlo experiments. 

ts_master.mat is required for running the main script; it contains the simulated data from Pakes, Ostrovsky, and Berry (2007); it was produced by the code available on Ostrovsky's website; it is enclosed.

To perform the comparison with kernel estimators from R package np comlete the following steps before running mc_mix_vs_freq_in_io.m:

- Set the value of variable FlagRunNPkernelEst in file mc_mix_vs_freq_in_io.m to 1 (if it is set to zero then only the comparison between the Bayesian and frequency estimators will be performed) 
- Install R and add the path to R.exe to the system variable PATH
- Install np package for R
- Set currPath in "npudensest.r" to the folder with the matlab files
