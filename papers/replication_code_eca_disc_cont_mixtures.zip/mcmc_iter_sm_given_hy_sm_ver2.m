function [m, N, s, mult_draw, AccFlag] = mcmc_iter_sm_given_hy_sm_ver2(y, mult_draw, s, N, m, hy, mu_, Hmu_, A_, Anuy_, Bnuy_, Am_, Amlogp_, ind_1_n)

AccFlag = 0;
n = length(y(1,:));

i1 = randi(n);
while 1
 i2 = randi(n);
 if i1 ~= i2
     break;
 end
end




if s(i1) == s(i2) %try to split jump to m+1
    jstar = s(i1);
    cs_ind = cumsum(mult_draw(jstar,1:max(i1,i2)));
    i1_inS = cs_ind(i1);
    i2_inS = cs_ind(i2);

    y_sijstar = y(:,logical(mult_draw(jstar,:)));
    lmly_sijstar = log_ml(sum(y_sijstar,2), sum(y_sijstar.^2,2), N(jstar), hy, mu_, Hmu_, Anuy_, Bnuy_);


    split_ind_init = randi([0 1],1,N(jstar));
    split_ind_init(i1_inS) = 0;
    split_ind_init(i2_inS) = 1;

    [split_ind_init, logGibbsPropProb, lml_prop, N0prop, N1prop] = gibbs_split_v2(y_sijstar, 100, hy, m+1, mu_, Hmu_, Anuy_, Bnuy_, A_, split_ind_init, i1_inS, i2_inS);
    %split_ind_init = zeros(1,N(jstar));
    [split_ind, logGibbsPropProb, lml_prop, N0prop, N1prop] = gibbs_split_v2(y_sijstar, 1, hy, m+1, mu_, Hmu_, Anuy_, Bnuy_, A_, split_ind_init, i1_inS, i2_inS);
    Nprop = [N;N1prop];  Nprop(jstar) = N0prop;


    logAccProbMp1 = lml_prop(1) + lml_prop(2) -(m+1)*gammaln(A_/(m+1)) + sum(gammaln(A_/(m+1)+Nprop)) - Am_*(m+1)*(log(m+1)^Amlogp_)...
                 - logGibbsPropProb ...
                 - (lmly_sijstar -m*gammaln(A_/m) + sum(gammaln(A_/m+N)) - Am_*(m)*(log(m)^Amlogp_));
    if rand < exp(logAccProbMp1)
        ind_y_sijstar = ind_1_n(logical(mult_draw(jstar,:)));

        try
        ind_y_simp1 = ind_y_sijstar(split_ind);
        catch
            warn = 1;
        end

        mult_draw(jstar,ind_y_simp1) = 0;
        mult_draw = [mult_draw; zeros(1,n)];
        mult_draw(m+1,ind_y_simp1) = 1;
        s(ind_y_simp1) = m+1;
        N = Nprop;
        m = m+1;
        AccFlag = 1;%mp1AccCount  = mp1AccCount + 1;
    end             

else %attempt to merge/jump m-1
   if s(i2) == m
        cs_ind1 = cumsum(mult_draw(s(i1),1:i1));
        cs_ind2 = cumsum(mult_draw(s(i2),1:i2));
        i1_inS = cs_ind1(i1);
        i2_inS = N(s(i1))+cs_ind2(i2);

       y_sijstar_m = [y(:,logical(mult_draw(s(i1),:))), y(:,logical(mult_draw(s(i2),:)))];
       split_ind = [zeros(1,N(s(i1))), ones(1,N(s(i2)))];
       lmly_sijstar_m = log_ml(sum(y_sijstar_m,2), sum(y_sijstar_m.^2,2), N(s(i1))+N(s(i2)), hy, mu_, Hmu_, Anuy_, Bnuy_);

       split_ind_init = randi([0 1],1,N(s(i1))+N(s(i2)));
       split_ind_init(i1_inS) = 0;
       split_ind_init(i2_inS) = 1;


       [split_ind_init, logGibbsPropProb, lml_prop, N0prop, N1prop] = gibbs_split_v2(y_sijstar_m, 100, hy, m, mu_, Hmu_, Anuy_, Bnuy_, A_, split_ind_init, i1_inS, i2_inS);
        %split_ind_init = zeros(1,N(jstar)+N(m));


       [logGibbsProb, lml] = gibbs_split_probability_v2(split_ind, y_sijstar_m, hy, m, mu_, Hmu_, Anuy_, Bnuy_, A_, split_ind_init, i1_inS, i2_inS);


        Nprop = N; Nprop(s(i1)) = Nprop(s(i1)) + Nprop(s(i2)); Nprop(s(i2),:) = [];

        logAccProbMm1 = lmly_sijstar_m -(m-1)*gammaln(A_/(m-1)) + sum(gammaln(A_/(m-1)+Nprop)) - Am_*(m-1)*(log(m-1)^Amlogp_) ...
                      - (sum(lml) -m*gammaln(A_/m) + sum(gammaln(A_/m+N)) - Am_*(m)*(log(m)^Amlogp_))...
                      + logGibbsProb;

        if rand < exp(logAccProbMm1)

            mult_draw(s(i1),logical(mult_draw(s(i2),:))) = 1;
            mult_draw(s(i2),:) = [];
            N = Nprop;
            m = m-1;
            AccFlag = -1;    
            if m > 1
                [s, ~] = find(mult_draw);
            else
                s = ones(n,1);
            end

            %mm1AccCount  = mm1AccCount + 1;
        end    
   end
   
end
