% Posterior simulator for the following model of y_i i =1,n:
% p(y_i) = \sum_{j=1}^m  alpha(j) * \phi(y_i,mu_j,(hy*nuy(j))^-1) 
% Observables: y_ik, k=dd+1,...,d and y_ik \in [yda(k,i),ydb(k,i)], k=1,...,dd

function [sim_mu, sim_alphaunn, sim_hy, sim_nuy, sim_m] ...
         = post_simulator_fixed_m(y, yda, ydb,...
                            mu0, alphaunn0, hy0, nuy0, m0,...
                            mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_,...
                            Nsim, jdt_flag, progress_step)


% some inputs check                                                      
szy = size(y); szyda = size(yda); szydb = size(ydb);
d = szy(1);
n = szy(2);
dd = szyda(1);
if szyda(2) ~= n || szydb(2) ~= n || szydb(1) ~= dd  
    error('post_simulator: input dimensions do not match');
end


% %precompute some statistics used by the mcmc algorithm
% x1x1t = zeros(dx+1,dx+1,n);
% x1ty = zeros(dx+1,n);
% for i=1:n
%     x1x1t(:,:,i)=x1(:,i)*x1(:,i)';
%     x1ty(:,i)=x1(:,i)*y(i);
% end

mMaxInit = m0;%max(20,m0); % upper bound on m used for memory allocation before for loop, if m exceed this then more memory is allocated

hyAccCount = 0;
mp1AccCount = 0;
mm1AccCount = 0;



sim_mu = zeros(d,mMaxInit,Nsim);
sim_alphaunn = zeros(mMaxInit,Nsim);
sim_hy = zeros(d,Nsim); 
sim_nuy = zeros(d,mMaxInit,Nsim);
sim_m = zeros(1,Nsim);

%sum_alphaunn = zeros(1,Nsim);
currlogLikelihood = zeros(1,Nsim); 
propPlogLikelihood = zeros(1,Nsim);
propMlogLikelihood = zeros(1,Nsim);

nonconvcount = 0;

mu=mu0; alphaunn=alphaunn0; hy=hy0; nuy=nuy0; m=m0;

tic


for sim = 1:Nsim


    
    [y,  mu, alphaunn, hy, nuy, m, hyAccCount] ...
         = mcmc_iter_given_m(y, yda, ydb, n, d, dd, ...
                                mu, alphaunn, hy, nuy, m,...
                                hyAccCount, ...
                                mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_);
    
%    sim_m(:,sim) = m; mswdraw = 0;% comment this if uncomment simulation of m below                       
% 	[mswdraw, b, mu, alphaunn, hy, hx, nuy, nux, sim_m(:,sim), currlogLikelihood(sim), propMlogLikelihood(sim), propPlogLikelihood(sim), mp1AccCount, mm1AccCount] ...
%          = mcmc_iter_m(y, x, x1, xmean, xvar, olsb, olserrvar, dx, n,...
%                         mp1AccCount, mm1AccCount, ...
%                         b, mu, alphaunn, hy, hx, nuy, nux, m,...
%                         b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_,Hb_b_);
                         
    % Update some intermediate vars if m changes or label switched                        
%     if sim_m(:,sim) ~= m
%         m = sim_m(:,sim);
%         Q = ComputeQ(n, m, dx, x, mu, nux, hx);
%         alpha = alphaunn./sum(alphaunn);     
%         [aexpQnorm, sumlogsumkaexpQ] = Qnormsumlogsum(Q,alpha);
%     else
%         if mswdraw && mswdraw ~= m % a random label switch
%            Qtemp = Q(:,m); Q(:,m) = Q(:,mswdraw); Q(:,mswdraw) = Qtemp;
%            Qtemp = aexpQnorm(:,m); aexpQnorm(:,m) = aexpQnorm(:,mswdraw); aexpQnorm(:,mswdraw) = Qtemp;     
%         end
%     end
 


    
    
% store simulated params
    sim_mu(:,1:m,sim) = mu;
    sim_alphaunn(1:m,sim) = alphaunn;
    sim_hy(:,sim) = hy; 
    sim_nuy(:,1:m,sim) = nuy; 
    sim_m(:,sim) = m;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if jdt_flag % simulate data for joint d-n tests
        [y, yda, ydb] = gen_data(n, dd, mu, alphaunn, hy, nuy, m);
%       %draw s cond param
%         alpha = alphaunn./sum(alphaunn);
%         if m == 1
%             s = ones(n,1);
%             mult_draw = ones(1,n);
%         else
% %           Q = ComputeQ(n, m, dx, x, mu, nux, hx);
% %           expQ = exp(bsxfun(@minus, Q, max(Q,[],2)));
% %           [s, mult_draw] = SCondParamDraw(expQ, alpha); 
%             mult_draw = mnrnd(1,alpha,n)'; [s, ~] = find(mult_draw);
% 
%         end
%         N = sum(mult_draw,2);
%         muy = mu(:,s); sdy = 1./sqrt(hy.*nuy(:,s)); 
%         y = normrnd(muy,sdy);
%         [yda,ydb] = create_trunc_bds(y(1:dd,:));

%        [y, s, mult_draw, N] = DrawYScondParams(x,x1,b, mu, alpha, hy, hx, nuy, nux);
        %recalculate precomputed stats
%         x1ty=bsxfun(@times, x1, y);
%         olsb=(x1*x1')\(x1*y');
%         olserrvar = mean((y - olsb'*x1).^2);
        
    end
    
 %   sim
 %   y
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    if floor(sim/progress_step) == sim/progress_step, % output current mcmc stats, e.g., acceptance rates
        msg = sprintf('Iter = %d Time = %d HyAccR = %d m = %d Params = %d %d %d %d', sim, toc, hyAccCount./sim, m, mu(1), alphaunn(1), hy(1), nuy(1,1));
        display(msg);
%         hy*nuy
%         msg2 = sprintf('Acc Counts: mp1 = %d mm1 = %d AlphaAcc = %d hx = %d hy = %d MaxMu = %d MaxNux = %d N = ...', mp1AccCount, mm1AccCount, alphaAccCount, hxAccCount, hyAccCount, max(muAccCount), max(nuxAccCount));
%         display(msg2);
   
%        muAccCount
%        nuxAccCount
%        hxAccCount
%         N'
%      alphaunn
%       hyAccCount
        %plot_postsim; 
        drawnow;
    end
end

