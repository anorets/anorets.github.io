function [ym, yvar, mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_] = EBayesDefaultPriorParams(y)

dy = length(y(:,1));
%Data dependent prior/empirical bayes
ym = mean(y,2);
yvar = cov(y');
ysd = sqrt(diag(yvar));
% Note change EB prior for no beta model
mu_ = ym;
Hmu_ = diag(1./diag(yvar));
A_ = 15; %original value
Am_ = 0.5; %original value
%A_ = 10; % pr sensetivity value

Amlogp_ = 0;
tempHym = 1./ysd; tempHyv = ones(dy,1); % mode and variance for scale params prior
tempNuym = ones(dy,1); tempNuyv = ones(dy,1);
GamAFromModeVar = @(md,v) ((md./sqrt(v) + sqrt((md./sqrt(v)).^2 + 4))*0.5).^2; 
Ahy_ = GamAFromModeVar(tempHym, tempHyv); Bhy_ = (Ahy_-1)./tempHym;
Anuy_ = GamAFromModeVar(tempNuym, tempNuyv); Bnuy_ = (Anuy_-1)./tempNuym;

