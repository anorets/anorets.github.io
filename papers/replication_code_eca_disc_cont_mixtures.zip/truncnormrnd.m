function z = truncnormrnd(m, s, a, b)
% generate z ~ N(m,s) truncated to [a,b]

% if ~ (isequal(size(m), size(s)) & isequal(size(a), size(s)) & isequal(size(a), size(b)))
%     stop = 1;
% end

Pa = normcdf(a, m, s);
Pb = normcdf(b, m, s);
z = norminv((Pb-Pa).*rand(size(m))+Pa,m,s);


ind_inf = find(Pa == 1);
z(ind_inf) = a(ind_inf)+10^-6;
ind_minf = find(Pb == 0);
z(ind_minf) = b(ind_minf)-10^-6;

ind_inf = find(z == inf);
z(ind_inf) = a(ind_inf)+10^-6;
ind_minf = find(z == -inf);
z(ind_minf) = b(ind_minf)-10^-6;