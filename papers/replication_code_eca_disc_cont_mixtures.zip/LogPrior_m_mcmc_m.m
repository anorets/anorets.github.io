function lpmf = LogPrior_m_mcmc_m(m,FQ)
lpmf = -FQ.Am_*m*(log(m)^FQ.Amlogp_);