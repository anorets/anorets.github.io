%returns logarithm of the gamma pdf
function res = lngampdf(x,A,B) 
res = (A - 1).*log(x) - B.*x - gammaln(A) + A.*log(B);
  
  