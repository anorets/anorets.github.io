%checklog likelihood
alpha = alphaunn./sum(alphaunn);
lpdf = 0;
pdfi = zeros(1,m);
tic
for i = 1:n
   for j = 1:m
      pdfi(j) = mvnpdf(y(:,i),mu(:,j),diag(1./(hy.*nuy(:,j))));
   end
   lpdf = lpdf + log(pdfi*alpha);
end
toc

tic
lpdf_vectorized = Ptildeyy_given_param(y, n, d, mu, alphaunn, hy, nuy, m, 1);
toc

diff = lpdf_vectorized - lpdf