figure(100)
titles_str = {'Market Size', 'Current Number of Firms', 'Number of Entrants', 'Number of Exits'};
for iind = 1:4
    subplot(2,2,iind)
    ts_master1tab{iind} = tabulate(ts_master(:,iind));
    scatter(ts_master1tab{iind}(:,1),ts_master1tab{iind}(:,3)./100, '.', 'MarkerEdgeColor', 'k')
    title(titles_str{iind});
end