function lml = log_ml(Sy, Sy2, N, hy, mu_, Hmu_, Anuy_, Bnuy_)

m=length(Sy(1,:));
d = length(Sy(:,1));
hNplusTau = (repmat(hy,1,m).*(N')+ diag(Hmu_)); %hNplusTau = hy.*N + diag(Hmu_);
barMu = (hy.*Sy + diag(Hmu_).*mu_)./ hNplusTau;
barBnuy = Bnuy_ + 0.5*(hy.*Sy2 + diag(Hmu_).*(mu_.^2) - hNplusTau.*barMu.^2);
barAnuy = Anuy_ + 0.5*repmat(N',d,1);

lml = sum(0.5*N'.*(log(hy) - log(2*pi)) + 0.5*log(diag(Hmu_)) + Anuy_.*log(Bnuy_) - gammaln(Anuy_) ...
      -( 0.5*log(hNplusTau) - gammaln(barAnuy) + barAnuy.*log(barBnuy)),1);
lml(N==0) = 0;
