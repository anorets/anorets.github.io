function lpdf = DiffLogPrior_mcmc_m(theta,m, FQ)
%log p(theta_{1m}|m) - log p(theta_{1m-1}|m-1)

[lpdf, ~,~] = lprior_nuy_mu_alphaunn_mJH(theta(1:FQ.d,:), theta(2*FQ.d+1,:)', theta(FQ.d+1:2*FQ.d,:), m, FQ.mu_, FQ.Hmu_, FQ.A_, FQ.Anuy_, FQ.Bnuy_, 0);

lpdf = lpdf + sum(lngampdf(theta(2*FQ.d+1,1:m-1),FQ.A_./m,1) - lngampdf(theta(2*FQ.d+1,1:m-1),FQ.A_./(m-1),1));



%FQ.A_*(1./m - 1./(m-1))*sum(log(theta(2*FQ.d+1,1:m-1)));% since prior for alphaunn depends on m, all components in alphaunn are included here


%[lpdf, ~,~] = Ptildeyy_given_param(FQ.y, FQ.n, FQ.d, theta(1:FQ.d,:), theta(d*FQ.d+1,:)', FQ.hy, theta(FQ.d+1:2*FQ.d,:), m);
