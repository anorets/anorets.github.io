% script to be run after post_simulator, it plots post simultor output and
% performs mean equality tests for first and second moments of post
close all

fig_start_n = 20;
batch_len = 100; % batch length for computing n.s.e.
burnin_len = 1;
ts_filter=burnin_len:Nsim;

true_param_flag = 0;

mMin = min(sim_m);
m0 = mMin;

hy_t_stats = [];
figure(fig_start_n+2)
for param_index = 1:d
%     subplot(1,2,1);
%     plot(squeeze(sim_hy(param_index,ts_filter)));
%     hold on;
    
%     subplot(1,2,2);
    [f, z] = ksdensity(squeeze(sim_hy(param_index,burnin_len:end)));
    figure(fig_start_n+param_index )
    plot(z,f); 
    hold on;
    if ~jdt_flag & true_param_flag
        z = [hy0, hy0];
        f = ylim;
        plot(z,f); 
        hold on;
    end
    hy_prdraws = gamrnd(Ahy_(param_index), 1./Bhy_(param_index), 10000, 1).^2; %for conjugate case comment ^2
    [f, z] = ksdensity(hy_prdraws);
    plot(z,f,'LineStyle','--'); hold on;
    title('hy_j');

    test_series = squeeze(sim_hy(param_index,:));
    t_stat_hy = (mean(test_series) - mean(hy_prdraws))./ sqrt(bmse(test_series,batch_len ).^2 + bmse(hy_prdraws,batch_len ).^2); % t statistics for means equality test
    t_stat_hysq = (mean(test_series.^2) - mean(hy_prdraws.^2))./ sqrt(bmse(test_series.^2,batch_len ).^2 + bmse(hy_prdraws.^2,batch_len ).^2); % t statistics for means equality test
    hy_t_stats = [hy_t_stats,t_stat_hy,t_stat_hysq]; 

end
hy_t_stats

figure(fig_start_n+2)
nu_t_stats = [];
for j = 1:mMin
    for param_index = 1:d  
        test_series = squeeze(sim_nuy(param_index,j,burnin_len:end));
%         subplot(1,2,1);
%         plot(test_series);
%         hold on;
% 
%         subplot(1,2,2);
        
        %figure(10*j+param_index)
        [f, z] = ksdensity(test_series,'Support','positive');
        %figure(fig_start_n+param_index )
        plot(z,f); 
        hold on;
        range = xlim; z = range(1):(range(2)-range(1))./200:range(2);
        f = gampdf(z, Anuy_(param_index), 1./Bnuy_(param_index));
        plot(z,f,'LineStyle','--');
        hold on
        
        nuy_prdraws = gamrnd(repmat(Anuy_(param_index),1,10000), repmat(1./Bnuy_(param_index),1,10000));

        t_stat_nuy1 = (mean(test_series) - mean(nuy_prdraws))./ sqrt(bmse(test_series,batch_len ).^2 + bmse(nuy_prdraws,batch_len ).^2); % t statistics for means equality test
        t_stat_nuy1sq = (mean(test_series.^2) - mean(nuy_prdraws.^2))./ sqrt(bmse(test_series.^2,batch_len ).^2 + bmse(nuy_prdraws.^2,batch_len ).^2); % t statistics for means equality test
        nu_t_stats = [nu_t_stats, t_stat_nuy1, t_stat_nuy1sq];
    end
end
nu_t_stats
if ~jdt_flag & true_param_flag
    subplot(1,2,2);
    for param_index = 1:m0
        z = [nuy0(param_index), nuy0(param_index)];
        f = ylim;
        plot(z,f); 
        hold on;
    end
end
nuy_prdraws = gamrnd(Anuy_(1), 1./Bnuy_(1), 10000, 1);
[f, z] = ksdensity(nuy_prdraws);
plot(z,f,'LineStyle','--'); hold on;
title('\nu_{yj}');
% test_series = squeeze(sim_nuy(1,:)) - squeeze(sim_nuy(2,:));
% t_stat_conv_nuy1_nuy2 = mean(test_series)./ bmse(test_series,batch_len ) % t statistics for means equality test


 figure(fig_start_n+4)
% 
% %sim_alpha1 = sim_alphaunn(1,burnin_len:end)./sum(sim_alphaunn(:,burnin_len:end));
% for param_index = 1:1
%     subplot(1,2,1);
%     plot(squeeze(sim_alphaunn(param_index,ts_filter)));
%     hold on;
% %     subplot(1,3,3);
% %     [f, z] = ksdensity(sim_alpha1(sim_alpha1 < 1), 'support', [0 1.000001]);
% %     plot(z,f); 
% %     hold on;
% end
% subplot(1,2,2);
 [f, z] = ksdensity(sum(sim_alphaunn(:,burnin_len:end)),'Support','positive');
 plot(z,f); 
 hold on;
 range = xlim; z = range(1):(range(2)-range(1))./200:range(2);
 f = gampdf(z, A_, 1);
 plot(z,f,'LineStyle','--'); hold on;
 title('Sum 1 to m of unnorm \alpha_j');
% 
 test_series = sum(sim_alphaunn);
 t_stat_unnalphasum = (mean(test_series)-A_)./ bmse(test_series,batch_len ) % t statistics for means equality test
 gamma_Ex2 = A_.^2+A_;
 test_series = sum(sim_alphaunn).^2;
 t_stat_unnalphasumsq = (mean(test_series)-gamma_Ex2)./ bmse(test_series,batch_len ) % t statistics for means equality test
% if ~jdt_flag & true_param_flag 
%    for param_index = 1:m0
%        f = ylim;
%        z = [alpha0(param_index), alpha0(param_index)];
%        plot(z,f); 
%        hold on;
%    end
% end

alpha_tstats = [];
figure(101)
sim_alpha = bsxfun(@rdivide, sim_alphaunn, sum(sim_alphaunn));
for param_index = 1:m0
    [f, z] = ksdensity(squeeze(sim_alpha(param_index,burnin_len:end)));%, 'Support', [0, 1]);
    %figure(fig_start_n+param_index )
    plot(z,f); 
    hold on;
    test_series = squeeze(sim_alpha(param_index,:));
    t_statAlpha = (mean(test_series)-1./m0)./ bmse(test_series,batch_len ); % t statistics for means equality test
    beta_Ex2 = ((A_./m0).^2 + (A_./m0).*((m0-1)*A_./m0)./(A_+1))./(A_).^2;
    test_series = squeeze(sim_alpha(param_index,:).^2);
    t_statAlpha2 = (mean(test_series)-beta_Ex2)./ bmse(test_series,batch_len ); % t statistics for means equality test
    alpha_tstats = [alpha_tstats, t_statAlpha, t_statAlpha2];
end
alpha_tstats
range = xlim; z = range(1):(range(2)-range(1))./200:range(2);
f = betapdf(z, A_./m0, (m0-1)*A_./m0);
plot(z,f,'LineStyle','--'); hold on;
title('\alpha_j');


mu_t_stats = [];
nuy_prdraws = gamrnd(repmat(Anuy_,1,10000), repmat(1./Bnuy_,1,10000));
mu_prdraws = normrnd(repmat(mu_,1,10000), 1./sqrt(nuy_prdraws.*diag(Hmu_)));

figure(fig_start_n+5)
for j = 1:mMin
    for param_index = 1:d 
        %figure(100+10*j+param_index)
         test_series = squeeze(sim_mu(param_index,j,burnin_len:end));
       
        [f, z] = ksdensity(test_series);
        %figure(fig_start_n+param_index )
        plot(z,f,'--'); 
        hold on;
        [f, z] = ksdensity(mu_prdraws(param_index,:)); plot(z,f);
        hold on
        
        
        t_stat_mu = (mean(test_series) - mu_(param_index))./ bmse(test_series,batch_len ); % t statistics for means equality test
        %test_series = squeeze(sim_mu(param_index,j,:)).^2 - (mu_(param_index).^2 + 1./Hmu_(testd,testd));
        %t_stat_musq = mean(test_series)./ bmse(test_series,batch_len ) % t statistics for means equality test
        t_stat_musq = (mean(test_series.^2) - mean(mu_prdraws(param_index,:).^2))./ sqrt(bmse(test_series.^2,batch_len ).^2 + bmse(mu_prdraws(param_index,:).^2,batch_len ).^2); % t statistics for means equality test
        mu_t_stats = [mu_t_stats,t_stat_mu,t_stat_musq]; 
    end
end
mu_t_stats
% % 
% % if ~jdt_flag & true_param_flag
% %     for param_index = 1:m0
% %         z = [mu0(testd,param_index), mu0(testd,param_index)];
% %         f = ylim;
% %         plot(z,f); 
% %         hold on;
% %     end
% % end
% % 
% % 
% % range = xlim; z = range(1):(range(2)-range(1))./200:range(2);
% % f = normpdf(z, mu_(testd), 1/sqrt(Hmu_(testd,testd))); %prior density for beta
% % plot(z,f,'LineStyle','--'); hold on;
% % title('\mu_{dj}');
% % 






freqm = zeros(1,max(sim_m));

m_vals = 1:50;
mpriorPMF = exp(-Am_.*m_vals.*(log(m_vals).^Amlogp_));
mpriorPMF = mpriorPMF./sum(mpriorPMF);
m_prior_mean = m_vals*mpriorPMF';
m2_prior_mean = (m_vals.^2)*mpriorPMF';
probm = mpriorPMF(1:max(sim_m));

if Amlogp_ == 0
    probm = exp(-Am_*(1:max(sim_m)))*(exp(Am_)-1);%knowm pmf constant
    m_prior_mean = 1./(1-exp(-Am_));
end



test_series = sim_m - m_prior_mean;
t_stat_m = mean(test_series)./ bmse(test_series,batch_len )

test_series = sim_m.^2 - m2_prior_mean;
t_stat_m2 = mean(test_series)./ bmse(test_series,batch_len )


for msupp = 1:max(sim_m)
   freqm(msupp) = sum(sim_m == msupp)./length(sim_m);
end
figure(fig_start_n+8)
subplot(1,2,1);
plot(squeeze(sim_m(ts_filter)));
hold on;

subplot(1,2,2);
plot(freqm)
hold on;
plot(probm,'LineStyle','--')
title('m');


ind_j = find(probm*Nsim > 25); % test only values of m for wich effective sample size at least 100 
for j = ind_j
    test_series = sim_m == j;
    t_stat_probmej = (mean(test_series)-probm(j))./ bmse(test_series,batch_len );
    [j, t_stat_probmej]
end



%%Uncomment the following if _xs posterior simulator is used
%     md_vals = 1:1/dx:51; 
%     mdpriorPMF = exp(-Am_.*md_vals.*(log(md_vals).^Amlogp_));
%     mdpriorPMF = mdpriorPMF./sum(mdpriorPMF);
%     md_prior_mean = md_vals*mdpriorPMF';
%     
%     test_series = sim_md./dx - md_prior_mean;
%     t_stat_dm = mean(test_series)./ bmse(test_series,batch_len )
%     
%     mpriorPMF(1) = mdpriorPMF(1);
%     mpriorPMF(2:(length(mdpriorPMF)-1)/dx+1) = sum(reshape(mdpriorPMF(2:end), dx, (length(mdpriorPMF)-1)/dx),1);
%       
%     m_vals = 1:51;
%     m_prior_mean = m_vals*mpriorPMF';
%     probm = mpriorPMF(1:max(sim_m));
% ind_j = find(mdpriorPMF*Nsim > 100); % test only values of m for wich effective sample size at least 100 
% for j = ind_j
%     test_series = sim_md./dx == md_vals(j);
%     t_stat_probmdej = (mean(test_series)-mdpriorPMF(j))./ bmse(test_series,batch_len );
%     [md_vals(j), t_stat_probmdej]
% end

% figure(fig_start_n+9)
% subplot(1,2,1);
% plot(squeeze(sim_md(ts_filter)));
% subplot(1,2,2);
% for j = ind_j
%    freqmd(j) = sum(sim_md./dx == md_vals(j))./length(sim_m);
% end
% plot(freqmd)
% hold on;
% plot(mdpriorPMF,'LineStyle','--')
% title('m');
%%%%%%%%%%%%%%%%%

%effective_sample_sz = var(sim_m)./(bmse(sim_m,100).^2)

