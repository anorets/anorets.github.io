%%%%%%%%%%%% Test Gibbs proposal for splitting, run from a breakpoint
%%%%%%%%%%%% inside mcmc_iter_given_m.m so that all the relevant variables
%%%%%%%%%%%% are defined

lml = log_ml(Sy, Sy2, N, hy, m, mu_, Hmu_, Anuy_, Bnuy_, A_);
%lml_w0 = log_ml([Sy, zeros(d,1)], [Sy2, zeros(d,1)], [N;0], hy, m, mu_, Hmu_, Anuy_, Bnuy_, A_);




%for y1,y2 calculate the joint distribution for the gibbs
% 0 0 
log_pr00 = sum(log_ml([y(:,1)+y(:,2), zeros(d,1)], [y(:,1).^2+y(:,2).^2, zeros(d,1)], [2; 0], hy, m, mu_, Hmu_, Anuy_, Bnuy_, A_)) ...
    +sum(gammaln(A_./m+[2;0]));
log_pr01 = sum(log_ml([y(:,1),y(:,2)], [y(:,1).^2,y(:,2).^2], [1; 1], hy, m, mu_, Hmu_, Anuy_, Bnuy_, A_)) ...
    +sum(gammaln(A_./m+[1;1]));
pr00 = 0.5./(1+exp(log_pr01-log_pr00))

split_ind = zeros(100,2);
NGibbsRuns = 10000;
for gscount = 1:NGibbsRuns
    [split_ind(gscount,:), logGibbsProb] = gibbs_split(y(:,1:2), 100, hy, m, mu_, Hmu_, Anuy_, Bnuy_, A_);
end
% for j = 1:m
%     barAnuy = Anuy_ + 0.5*N(j);
%     barMu = diag(Hmu_).*mu_ + N(j).*hy.*mean()
%     
%     
% end

length(find(sum(split_ind,2)==0))/NGibbsRuns
length(find(sum(split_ind,2)==2))/NGibbsRuns


indic0 = (sum(split_ind,2)==0); figure(1); plot(indic0(1:1:end));

indic2 = (sum(split_ind,2)==2); figure(2); plot(indic2(1:1:end));

