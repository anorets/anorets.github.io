%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% This is the main script for replicating the results reported in 
%% ``Adaptive Bayesian Estimation of Mixed Discrete-Continuous Distributions under Smoothness and Sparsity'' by Norets and Pelenis
%% Code Author: Andriy Norets
%% Date: 2021
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('ts_master.mat'); % load the data simulated in Pakes, Ostrovsky, and Berry (2007)

d = 4; % dimension of observation vector 
dd = 4; % dimension of discrete components, d-dd is the dimension of the continuous part of the observation
n = 500; % sample size Monte Carlo simulations
mc_len = 50; % number of Monte Carlo iterations
Nsim = 10000; % number of MCMC iterations for fixed m models within each Monte Carlo iteration
NsimMult4VarM = 1;% Nsim*NsimMult4VarM=number of MCMC iterations for variable m models
jdt_flag=0; % set to 1 to perform Geweke's joint distribution tests for correctness of posterior simulator design and implementation, also use small n=5 for this,  
progress_step = Nsim; % some MCMC stats are printed on screen every progress_step iterations
burnin = 0.1*Nsim; % number of initial MCMC iterations to be discarded for each simulator run
bmse_batch_len = floor(sqrt(Nsim-burnin)); % batch size for calculting batched numerical standard errors for MCMC sample average estimators
thin_step = Nsim./100; % Only posterior draws with indices burnin:thin_step:Nsim are used to compute MCMC estimators for posterior predictive distributions
fixed_m_max = 20; % for fixed m, estimation is performed for m = 1,...,fixed_m_max
m_var_init = 13; % initial value of m for variable m models

FlagRunNPkernelEst = 1; % set to 0 not to perform calls to R package np; when FlagRunNPkernelEst = 1, perform steps outlined in readme.txt to enable the call of R package np from this code


%%%%%%%%%%%%%%% Extract data from ts_master.mat

recoded_ts = ts_master(:,1)*10^4+ts_master(:,2)*10^2+ts_master(:,3)*10+ts_master(:,4);
recoded_tab = tabulate(recoded_ts);
non0ind = find(recoded_tab(:,2));
recoded_tabnon0 = recoded_tab(non0ind,:);
%sum(recoded_tabnon0(:,3));
recoded_population = recoded_tabnon0(:,1);
y_pop(1,:) = floor(recoded_population(:,1)./10^4)';
y_pop(2,:) = floor((recoded_population(:,1)' - y_pop(1,:).*10^4)./10^2);
y_pop(3,:) = floor((recoded_population(:,1)' - y_pop(1,:).*10^4 - y_pop(2,:).*10^2)./10);
y_pop(4,:) = recoded_population(:,1)' - y_pop(1,:).*10^4 - y_pop(2,:).*10^2 - y_pop(3,:).*10;
[yda_pop,ydb_pop] = create_trunc_bds(y_pop, dd); % create intervals for the latent variables corresponding to discrete integer values
n_eval = length(y_pop(1,:));

%pre-allocate some variables
pmdf = zeros(n_eval,length(burnin:thin_step:Nsim));
tv_error_table = zeros(mc_len, max(fixed_m_max)+3);
max_error_table = zeros(mc_len, max(fixed_m_max)+3);
L2error_table = zeros(mc_len, max(fixed_m_max)+3);
mean_m_splitmerge = zeros(1,mc_len);
mean_m_rjmcmc = zeros(1,mc_len);

%%%%%%%%%% Loop for Monte Carlo iterations
tic
for mc_ind = 1:mc_len
    
    rng(123462+mc_ind, 'twister');

    mc_ind
    toc
    
	%%%%%%%%%%%% draw a random sample from the population in recoded_tabnon0

    mult_draw = mnrnd(1,recoded_tabnon0(:,3)./100,n)'; 
    [s, ~] = find(mult_draw);
    recoded_sample = recoded_tabnon0(s,1);

    recoded_sample_tab = tabulate(recoded_sample);
    non0indsample = find(recoded_sample_tab(:,2));
    recoded_sample_tabnon0 = recoded_sample_tab(non0indsample,:);

    sum(recoded_sample_tabnon0(:,3)./100)

    N = length(recoded_tabnon0(:,1));
    estimated_prob = zeros(N,1);


    tsumm = 0;
    for i=1:length(recoded_sample_tabnon0(:,1))
        ind = find(recoded_sample_tabnon0(i,1) == recoded_tabnon0(:,1));
        estimated_prob(ind) = recoded_sample_tabnon0(i,3)./100;
        tsumm = tsumm + recoded_sample_tabnon0(i,3);%./100;
    end


    estimated_exact_prob = [estimated_prob, recoded_tabnon0(:,3)./100]; % contains sample frequencies and the corresponding population probabilities 
    %sum(estimated_exact_prob)
    %sum(abs(estimated_exact_prob(:,1)-estimated_exact_prob(:,2)))
    max_freq_error = max(abs(estimated_exact_prob(:,1)-estimated_exact_prob(:,2)));
    freq_error = sum(abs(estimated_exact_prob(:,1)-estimated_exact_prob(:,2)));
    freq_L2error = sqrt(sum((estimated_exact_prob(:,1)-estimated_exact_prob(:,2)).^2));
    tv_error_table(mc_ind,1) = freq_error;
    max_error_table(mc_ind,1) = max_freq_error;
    L2error_table(mc_ind,1) = freq_L2error;
    
    
    %%%%%%%%%%%%%% format data for estimation by mixtures
    clear y;
    y(1,:) = floor(recoded_sample(:,1)./10^4)';
    y(2,:) = floor((recoded_sample(:,1)' - y(1,:).*10^4)./10^2);
    y(3,:) = floor((recoded_sample(:,1)' - y(1,:).*10^4 - y(2,:).*10^2)./10);
    y(4,:) = recoded_sample(:,1)' - y(1,:).*10^4 - y(2,:).*10^2 - y(3,:).*10;
    [yda,ydb] = create_trunc_bds(y, dd);
    bds = [yda; ydb];
	
	
	%%%%%%%%%%%%%%%%% Set prior hyperparameters
    [ymean, yvar, mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_] = EBayesDefaultPriorParams(y); % edit EBayesDefaultPriorParams.m to change prior hyperparameters


    %%%%%%%%%%%%% Run MCMC estimation for fixed m models and variable m models (two different algorithms are used for the latter, split/merge and approx. optimal reversible jump)
	
     for m = 1:fixed_m_max + 2 % estimation results for fixed m models are also obtained in additiona to variable m ones
   % for m = fixed_m_max+2:fixed_m_max + 2 % only variable m models are estimated by optimal rjmcmc  
   %      for m = fixed_m_max+1:fixed_m_max + 2 % only variable m models are estimated by split/merge and optimal rjmcmc  
        %Initialize parameters
        mu = repmat(ymean, 1, m);
        hy = 1./(diag(yvar));%gamrnd(Ahy_, 1./Bhy_);%hy = 1;
        nuy = ones(d,m);
        alphaunn = gamrnd(ones(1,m).*A_./m,1)'; alpha0=alphaunn/sum(alphaunn); 
        % Call posterior simulator %%%%%%%%%%%%%%%%%%%%%%%%%% 
        rng(123462+mc_ind + m, 'twister');
        if m <= fixed_m_max 
            [sim_mu, sim_alphaunn, sim_hy, sim_nuy, sim_m] ...
                     = post_simulator_fixed_m(y, yda, ydb,...
                                        mu, alphaunn, hy, nuy, m,...
                                        mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_,...
                                        Nsim, jdt_flag, progress_step);
        elseif m == fixed_m_max + 1
            [sim_mu, sim_alphaunn, sim_hy, sim_nuy, sim_m] ...
                     = post_simulator_split_merge(y, yda, ydb,...
                                        mu(:,1:m_var_init), alphaunn(1:m_var_init,:), hy, nuy(:,1:m_var_init), m_var_init,...
                                        mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_,...
                                        Nsim*NsimMult4VarM, jdt_flag, progress_step);
             mean_m_splitmerge(mc_ind) = mean(sim_m(burnin:end));
             nse_m_splitmerge(mc_ind) = bmse(sim_m(burnin:end), bmse_batch_len);

        else 
            [sim_mu, sim_alphaunn, sim_hy, sim_nuy, sim_m] ...
                     = post_simulator_optrjmcmc(y, yda, ydb,...
                                        mu(:,1:m_var_init), alphaunn(1:m_var_init,:), hy, nuy(:,1:m_var_init), m_var_init,...
                                        mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_,...
                                        Nsim*NsimMult4VarM, jdt_flag, progress_step);
            mean_m_rjmcmc(mc_ind) = mean(sim_m(burnin:end));
            nse_m_rjmcmc(mc_ind) = bmse(sim_m(burnin:end), bmse_batch_len); %numerical standard error for posterior mean

            %%%%%%%%%%%%%%%Produce figure 2 in the paper
            if mc_ind < 3 %
                freqm = zeros(1,max(sim_m));
                for msupp = 1:max(sim_m)
                   freqm(msupp) = sum(sim_m == msupp)./length(sim_m);
                end
                probm = exp(-Am_*(1:max(sim_m)))*(exp(Am_)-1);%knowm pmf constant for Amlogp_ == 0
                figure(103)
                subplot(2,2,2*(mc_ind-1)+1); plot(squeeze(sim_m),'k');
                xlabel('Iterations'); ylabel('m');
                title(strcat('MCMC run for MC Sample', 32, num2str(mc_ind))); hold on;
                non0freq_ind = find(freqm>0);
                subplot(2,2,2*(mc_ind-1)+2); scatter(non0freq_ind,freqm(non0freq_ind), 'k', 'o', 'filled'); hold on;
                scatter(1:max(sim_m), probm,  'k', 'o'); xlabel('m'); ylabel('pmf'); legend('posterior','prior')
            end
        end
        i = 1;
        for sim = burnin:thin_step:length(sim_m)
            pmdf(:,i) = Py_given_param(y_pop, yda_pop, ydb_pop, n_eval, d, dd, ...
                    sim_mu(:,1:sim_m(sim),sim), sim_alphaunn(1:sim_m(sim),sim), sim_hy(:,sim), sim_nuy(:,1:sim_m(sim),sim), sim_m(sim))';
            i = i+1;
        end
        mix_estimated_prob = mean(pmdf,2);
        mix_error = sum(abs(mix_estimated_prob-estimated_exact_prob(:,2)));
        mix_L2error = sqrt(sum((mix_estimated_prob-estimated_exact_prob(:,2)).^2));
        max_mix_error = max(abs(mix_estimated_prob-estimated_exact_prob(:,2)))
        tv_error_table(mc_ind,1+m) = mix_error;
        L2error_table(mc_ind,1+m) = mix_L2error;
        max_error_table(mc_ind,1+m) = max_mix_error;
     end
    
	%%%%%%%%%%%%%%%%%%  Run kernel estimation by R package np
     if FlagRunNPkernelEst
        dataforR= y';
        save 'EstDataForR.txt' dataforR -ascii
         
        PredProbNP = CompPredUDensNP(y_pop, 1);
        np_L2error = sqrt(sum((PredProbNP-estimated_exact_prob(:,2)).^2));
        np_error = sum(abs(PredProbNP-estimated_exact_prob(:,2)));
        max_np_error = max(abs(PredProbNP-estimated_exact_prob(:,2)))
        L2error_table(mc_ind,2+m) = np_L2error;
        tv_error_table(mc_ind,2+m) = np_error;
        max_error_table(mc_ind,2+m) = max_np_error;
    end
     
     
    tablen = length(max_error_table(1,:));
    tab_non0ind = [1,tablen-2,tablen-1,tablen]; % tab_non0ind = 1:tablen; %to also print fixed m results
    max_error_table(1:mc_ind,tab_non0ind)
    tv_error_table(1:mc_ind,:)
    mean_m_rjmcmc(1:mc_ind)
    mean_m_splitmerge(mc_ind)
end
mean_max_error = mean(max_error_table)
std_max_error = std(max_error_table);
mean_tv_error = mean(tv_error_table)
std_tv_error = std(tv_error_table);
mean_L2error = mean(L2error_table)

%save('mc_mix_vs_freq_in_io_11_06_19_Am05.mat'); %load('mc_mix_vs_freq_in_io_5_22_21_Am05A10.mat');
save('mc_mix_vs_freq_in_io_8_6_21.mat'); 
figure(5)
subplot(1,3,1)
scatter(1:fixed_m_max, mean_tv_error(2:end-3), 'MarkerEdgeColor', 'k'); hold on; %plot(mean_tv_error(2:end-2)); hold on;
plot(repmat(mean_tv_error(1),1,fixed_m_max), '--', 'Color', 'k', 'LineWidth', 2); hold on;
plot(repmat(mean_tv_error(end-1),1,fixed_m_max),  'Color', 'k', 'LineWidth', 2); hold on
plot(repmat(mean_tv_error(end),1,fixed_m_max), ':', 'Color', 'k', 'LineWidth', 2); hold on;
ylim([0 1])
%legend('fixed m estimator', 'frequency estimator', 'variable m estimator', 'kernel estimator');
xlabel('m');
title 'L_1 error';%ylabel('Average TVD error')
%plot(repmat(mean_tv_error(end-1)),1,fixed_m_max); hold on;

 subplot(1,3,3)
%figure(3)
scatter(1:fixed_m_max, mean_max_error(2:end-3), 'MarkerEdgeColor', 'k'); hold on;
plot(repmat(mean_max_error(1),1,fixed_m_max), '--', 'Color', 'k', 'LineWidth', 2); hold on;
plot(repmat(mean_max_error(end-1),1,fixed_m_max), 'Color', 'k', 'LineWidth', 2); hold on;
plot(repmat(mean_max_error(end),1,fixed_m_max), ':', 'Color', 'k', 'LineWidth', 2); hold on;
legend('fixed m', 'frequency', 'variable m', 'kernel estimator');
xlabel('m');
title 'L_\infty error';%ylabel('Average sup error')
ylim([0 0.02])

%figure(4)
subplot(1,3,2)
scatter(1:fixed_m_max, mean_L2error(2:end-3), 'MarkerEdgeColor', 'k'); hold on; %plot(mean_tv_error(2:end-2)); hold on;
plot(repmat(mean_L2error(1),1,fixed_m_max), '--', 'Color', 'k', 'LineWidth', 2); hold on;
plot(repmat(mean_L2error(end-1),1,fixed_m_max),  'Color', 'k', 'LineWidth', 2); hold on
plot(repmat(mean_L2error(end),1,fixed_m_max), ':', 'Color', 'k', 'LineWidth', 2); hold on;
ylim([0 1])
%legend('fixed m estimator', 'frequency estimator', 'variable m estimator', 'kernel estimator');
xlabel('m');
title 'L_2 error';%ylabel('Average L_2 error')
ylim([0 0.05])

