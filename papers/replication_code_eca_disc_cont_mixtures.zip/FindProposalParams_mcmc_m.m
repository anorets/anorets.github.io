function prop_param = FindProposalParams_mcmc_m(theta, m, thetamp1_0, FQ)


z = thetamp1_0;
% mu = [theta(1:FQ.d,:), z(1:FQ.d,1)];
% alphaunn = [theta(2*FQ.d+1,:), z(2*FQ.d+1,1)]';
% nuy = [theta(FQ.d+1:2*FQ.d,:), z(FQ.d+1:2*FQ.d,1)];

%LklhdPrior = @(z) -1*(Ptildeyy_given_param(FQ.y, FQ.n, FQ.d, [theta(1:FQ.d,:), z(1:FQ.d,1)], [theta(2*FQ.d+1,:), z(2*FQ.d+1,1)]', FQ.hy, [theta(FQ.d+1:2*FQ.d,:), z(FQ.d+1:2*FQ.d,1)], m+1) + lprior_nuy_mu_alphaunn_mJH([theta(1:FQ.d,:), z(1:FQ.d,1)], [theta(2*FQ.d+1,:), z(2*FQ.d+1,1)]', [theta(FQ.d+1:2*FQ.d,:), z(FQ.d+1:2*FQ.d,1)], m+1, FQ.d, FQ.mu_, FQ.Hmu_, FQ.A_, FQ.Anuy_, FQ.Bnuy_));

LklhdPrior = @(z) logLklhdPriorDerivativesThetam(FQ.y, FQ.n, FQ.d, [theta(1:FQ.d,:), z(1:FQ.d,1)], [theta(2*FQ.d+1,:), z(2*FQ.d+1,1)]', FQ.hy, [theta(FQ.d+1:2*FQ.d,:), z(FQ.d+1:2*FQ.d,1)], m+1, FQ.mu_, FQ.Hmu_, FQ.A_, FQ.Anuy_, FQ.Bnuy_);

MinusLklhdPrior = @(z) (-1)* LklhdPrior(z);

% options = optimoptions(@LklhdPrior,'Algorithm','quasi-newton');
% [x fval] = fminunc(anonrosen,[-1;2],options)
%tic
[nstatus, thetamp1, H, fval_newton] = NewtonMethod(thetamp1_0, LklhdPrior, 10^(-2), 100, FQ.d+1);
%nstatus = 0; thetamp1 = thetamp1_0;  [f, J, H] = LklhdPrior(thetamp1_0); H = Negadefinize(H);
%newton_time = toc

%tic
% lb = [-inf*ones(FQ.d,1); 10^-6*ones(FQ.d+1,1)];
% [thetamp1_mopt,fval_matlab,exitflag,output,lambda,grad,hessian] = fmincon(MinusLklhdPrior,thetamp1_0,[],[],[],[],lb,[]);
% matlab_opttime = toc

% if fval_newton < -fval_matlab
%     thetamp1 = thetamp1_mopt;
%    H = - hessian; 
%    matlab_better = 1
% end

if nstatus
%    nstatus
end
prop_param{1} = thetamp1; 
prop_param{2} = -H; 
try
  %prop_param{3} = inv(prop_param{2});
  temp = mvnrnd(prop_param{1}', inv(prop_param{2}))';
catch
  prop_param{1} = thetamp1_0; 
  %[f, J, H] = LklhdPrior(thetamp1_0); 
  prop_param{2} = (10^-4)*eye(2*FQ.d+1);%-Negadefinize(H);
  prop_param{3} = inv(prop_param{2});
end

