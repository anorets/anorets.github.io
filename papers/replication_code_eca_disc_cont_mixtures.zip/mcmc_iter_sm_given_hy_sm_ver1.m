function [m, N, s, mult_draw, AccFlag] = mcmc_iter_sm_given_hy_sm_ver1(y, mult_draw, s, N, m, hy, mu_, Hmu_, A_, Anuy_, Bnuy_, Am_, Amlogp_, ind_1_n)

AccFlag = 0;
n = length(y(1,:));
if rand < 0.5 %try to jump to m+1
jstar = randi(m);

y_sijstar = y(:,logical(mult_draw(jstar,:)));
lmly_sijstar = log_ml(sum(y_sijstar,2), sum(y_sijstar.^2,2), N(jstar), hy, mu_, Hmu_, Anuy_, Bnuy_);

switch N(jstar)
    case 0
        lml_prop = [0,0];
        Nprop = [N;0];
        logGibbsPropProb = 0;
        split_ind = logical(0);
    case 1
        lml_prop = [lmly_sijstar,0];
        Nprop = [N;0];
        logGibbsPropProb = 0;
        split_ind = logical(0);

    otherwise
        split_ind_init = randi([0 1],1,N(jstar));
        [split_ind_init, logGibbsPropProb, lml_prop, N0prop, N1prop] = gibbs_split(y_sijstar, 100, hy, m+1, mu_, Hmu_, Anuy_, Bnuy_, A_, split_ind_init);
        %split_ind_init = zeros(1,N(jstar));
        [split_ind, logGibbsPropProb, lml_prop, N0prop, N1prop] = gibbs_split(y_sijstar, 1, hy, m+1, mu_, Hmu_, Anuy_, Bnuy_, A_, split_ind_init);
        Nprop = [N;N1prop];  Nprop(jstar) = N0prop;

end
logAccProbMp1 = lml_prop(1) + lml_prop(2) -(m+1)*gammaln(A_/(m+1)) + sum(gammaln(A_/(m+1)+Nprop)) - Am_*(m+1)*(log(m+1)^Amlogp_)...
             - logGibbsPropProb - log(1/m)...
             - (lmly_sijstar -m*gammaln(A_/m) + sum(gammaln(A_/m+N)) - Am_*(m)*(log(m)^Amlogp_)) ...
             + log(1/m);
if rand < exp(logAccProbMp1)
    ind_y_sijstar = ind_1_n(logical(mult_draw(jstar,:)));

    try
    ind_y_simp1 = ind_y_sijstar(split_ind);
    catch
        warn = 1;
    end

    mult_draw(jstar,ind_y_simp1) = 0;
    mult_draw = [mult_draw; zeros(1,n)];
    mult_draw(m+1,ind_y_simp1) = 1;
    s(ind_y_simp1) = m+1;
    N = Nprop;
    m = m+1;
    AccFlag = 1;%mp1AccCount  = mp1AccCount + 1;
end             

else %attempt to jump m-1
if m > 1
jstar = randi(m-1);
if N(jstar) == 0 && N(m) == 0
  lmly_sijstar_m = 0;
  logGibbsProb = 0;
  lml = [0, 0];
else
   y_sijstar_m = [y(:,logical(mult_draw(jstar,:))), y(:,logical(mult_draw(m,:)))];
   split_ind = [zeros(1,N(jstar)), ones(1,N(m))];
   lmly_sijstar_m = log_ml(sum(y_sijstar_m,2), sum(y_sijstar_m.^2,2), N(jstar)+N(m), hy, mu_, Hmu_, Anuy_, Bnuy_);

   split_ind_init = randi([0 1],1,N(jstar)+N(m));
   [split_ind_init, logGibbsPropProb, lml_prop, N0prop, N1prop] = gibbs_split(y_sijstar_m, 100, hy, m, mu_, Hmu_, Anuy_, Bnuy_, A_, split_ind_init);
    %split_ind_init = zeros(1,N(jstar)+N(m));

    if N(m) == 0
        stophere = 1;
    end

   [logGibbsProb, lml] = gibbs_split_probability(split_ind, y_sijstar_m, hy, m, mu_, Hmu_, Anuy_, Bnuy_, A_, split_ind_init);


end

Nprop = N(1:m-1,1); Nprop(jstar) = Nprop(jstar) + N(m);

logAccProbMm1 = lmly_sijstar_m -(m-1)*gammaln(A_/(m-1)) + sum(gammaln(A_/(m-1)+Nprop)) - Am_*(m-1)*(log(m-1)^Amlogp_) ...
              - log(1/(m-1))...
             - (sum(lml) -m*gammaln(A_/m) + sum(gammaln(A_/m+N)) - Am_*(m)*(log(m)^Amlogp_))...
             + log(1/(m-1)) + logGibbsProb;

if rand < exp(logAccProbMm1)
    s(logical(mult_draw(m,:))) = jstar;
    mult_draw(jstar,logical(mult_draw(m,:))) = 1;
    mult_draw = mult_draw(1:m-1,:);
    N = Nprop;
    m = m-1;
    AccFlag = -1;%mm1AccCount  = mm1AccCount + 1;
end    
end
end
