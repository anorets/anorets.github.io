function [yda,ydb] = create_trunc_bds_fromystar(ystar)
yda = floor(ystar);
ydb = ceil(ystar);
dd = length(ystar(:,1));
% for i = 1:dd
%     minydai = min(yda(i,:));
%     minind = find(yda(i,:) == minydai);
%     yda(i, minind) = -inf;
% 	maxydbi = max(ydb(i,:));
%     maxind = find(ydb(i,:) == maxydbi);
%     ydb(i, maxind) = inf;
% end