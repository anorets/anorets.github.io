function [lpdf, Jlpdf, Hlpdf] = logLklhdPriorDerivativesThetam(y, n, d, mu, alphaunn, hy, nuy, m, mu_, Hmu_, A_, Anuy_, Bnuy_)
%Compute log p(y,y^\ast|\theta_{1m},m) and it 1st and 2nd derivatives wrt \theta_m

[lpdf1, Jlpdf1, Hlpdf1] = Ptildeyy_given_param(y, n, d, mu, alphaunn, hy, nuy, m, 1);

[lpdf2, Jlpdf2, Hlpdf2] = lprior_nuy_mu_alphaunn_mJH(mu, alphaunn, nuy, m, mu_, Hmu_, A_, Anuy_, Bnuy_,1);

lpdf = lpdf1+lpdf2;
Jlpdf = Jlpdf1+Jlpdf2;
Hlpdf = Hlpdf1+Hlpdf2;