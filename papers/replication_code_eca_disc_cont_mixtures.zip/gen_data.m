% Generate sample of size n from a mixture of multivariate normals, where first dd coordinates are discrete

function [y, yda, ydb] = gen_data(n, dd, mu, alphaunn, hy, nuy, m)

alpha = alphaunn./sum(alphaunn);
if m == 1
    s = ones(n,1);
    mult_draw = ones(1,n);
else
    mult_draw = mnrnd(1,alpha,n)'; [s, ~] = find(mult_draw);
end
muy = mu(:,s); sdy = 1./sqrt(hy.*nuy(:,s)); 
y = normrnd(muy,sdy);
if dd
    [yda,ydb] = create_trunc_bds_fromystar(y(1:dd,:));
else
    yda = []; ydb = [];
end