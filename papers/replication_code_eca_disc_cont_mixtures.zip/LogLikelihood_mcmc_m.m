function lpdf = LogLikelihood_mcmc_m(theta, m, FQ)

[lpdf, ~,~] = Ptildeyy_given_param(FQ.y, FQ.n, FQ.d, theta(1:FQ.d,:), theta(2*FQ.d+1,:)', FQ.hy, theta(FQ.d+1:2*FQ.d,:), m, 0);