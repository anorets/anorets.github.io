% code for Norets and Pelenis (2018)
% changing dx (dimension of x) and un/commenting different DGPs below
% will produce different raws in Table 1.  Current settings are for raw 3
% Calls to R package np are commentred out so the np results will not be produced
% uncommetning calls to np would require installation of R, np package in R, 
% setting paths for R, changing paths in enclosed "npest.r"
% and making sure R can be called from matlab using:
% system('R CMD BATCH npest.r');
clear; close all;

if isunix
    % Code to run on Linux plaform - if run on linux put a path to matlab
    % files here:
    path(path,'/home/anorets/fmmncode')
elseif ispc
    % Code to run on Windows platform
else
    disp('Cannot recognize platform')
end

%initialization for estimation from art data or joint distribution tests
Nsim = 100000;% # of MCMC iterations per simulator run
jdt_flag = 1;
true_param_flag = 1;
if jdt_flag
   n = 5; 
else
    n = 1000; 
end
progress_step = 100;
burnin = ceil(Nsim*0.1);

FlagRunNPkernelEst = 0;

mc_len = 1;% # of of Monte Carlos (simulated datasets on which MCMC estimation is done)
rmse=zeros(1,mc_len);
mae=zeros(1,mc_len);
rmsenp=zeros(1,mc_len);
maenp=zeros(1,mc_len);

for mc_ind = 1:mc_len
%initialize random var generator
rng(123462+mc_ind, 'twister');
%rng(235462);


% %%%%%%%%    DGP - model at a draw from prior conditional on a given m0   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% x = 1*(-1+2.*rand(dx,n)); x1 = [ones(1,n); x]; 
% m0 = 3; % DGP # of mixture components
% % DGP params = prior draw
% [b0, mu0, alpha0, hy0, hx0, nuy0, nux0] = PriorDraw(m0, b_, invHb_, mu_, invHmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_);
% [y, s0, mult_draw0, N0]=DrawYScondParams(x,x1,b0, mu0, alpha0, hy0, hx0, nuy0, nux0);
% dgpcpdfeval = @(ypdf,xpdf) pdfycondxparam(ypdf, xpdf, [ones(1,length(xpdf(1,:)));xpdf], b0, mu0, alpha0, hy0, hx0, nuy0, nux0, m0);
%End: Use this for jdt and data generated from prior %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%% A simple DGP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
d = 4; %dimension of data 
dd = 2; % dimesnion of discrete variables
dc = d-dd;
% yc = zeros(dc,n); %continuous variables
% yd = zeros(dd,n); %continuous variables
% yc_var = rand(dc,dc); yc_var = (yc_var*yc_var')./dd;
% yc = mvnrnd(zeros(dc,1),yc_var,n)';%normrnd(0.5, 1./sqrt(12),1,n);% 
% beta01 = 1:dd;
% beta02 = dd:-1:1;
% ystar = [beta01;beta02]*yc + normrnd(0,1,size(yd));
% [yda,ydb] = create_trunc_bds(ystar);
% y = [ystar; yc]; %when data is not simulated, initialize with 0.5(yda+ydb) for finite
%End: Simple DGP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%DGP mixture

m0 = 3;
mu0 = [-1.*ones(d,1), 2.*ones(d,1), 5.*ones(d,1)];
hy0 = ones(d,1);%gamrnd(Ahy_, 1./Bhy_);%hy = 1;
nuy0 = 0.1*[ones(d,1), 2.*ones(d,1), 3.*ones(d,1)];
alphaunn0 = [0.5; 0.3; 0.2]; alpha0=alphaunn0/sum(alphaunn0); 


[y, yda, ydb] = gen_data(n, dd, mu0, alphaunn0, hy0, nuy0, m0);




% %Save data in text file for np in R
% dataforR=[x' y'];
% save 'EstDataForR.txt' dataforR -ascii

%Data dependent prior/empirical bayes
if jdt_flag
    mu_ = rand(d,1);
    Hmu_=diag(ones(d,1));
    A_=0.5;
    Ahy_=2*ones(d,1); 
    Bhy_=ones(d,1); 
    Anuy_=2*(1:d)';%ones(d,1);
    Bnuy_= (d:-1:1)';%ones(d,1); 
    Am_=1; 
    Amlogp_=2;
    ymean=mu_;
    yvar = eye(d);
else
    [ymean, yvar, mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_] = EBayesDefaultPriorParams(y);
end
%Hmu_mu_= Hmu_*mu_;
%invHmu_ = inv(Hmu_);
%prior_pred_analysis
%[xmean, xvar, olsb, olserrvar, b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_] = EBayesDefaultPriorParams(y,x,x1);

%Initialize parameters
m = 3;
mu = repmat(ymean, 1, m);%.*(1:m);
hy = 1./(diag(yvar));%gamrnd(Ahy_, 1./Bhy_);%hy = 1;
nuy = ones(d,m);
alphaunn = gamrnd(ones(1,m).*A_./m,1)'; alpha0=alphaunn/sum(alphaunn); 


% Call posterior simulator %%%%%%%%%%%%%%%%%%%%%%%%%% 
[sim_mu, sim_alphaunn, sim_hy, sim_nuy, sim_m] ...
         = post_simulator_split_merge(y, yda, ydb,...   %
                            mu, alphaunn, hy, nuy, m,...
                            mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_,...
                            Nsim, jdt_flag, progress_step);

                      
                        
%%%%%%%%%%  plot priors and posteriors for parameters, uncomment for jdt                  
plot_test_postsimout; 
%%%%%%%%%


% %plot cond pdf's post mean and q and 1-q quantiles
%  q = 0.0001;
%  plotpostpdfdraws(100, ygridPlot, xgridPlot, sim_b, sim_mu, sim_alphaunn, sim_hy, sim_hx, sim_nuy, sim_nux, sim_m, Nsim, 10, q);
%  plotdgpcpdf(100, ygridPlot, xgridPlot, dgpcpdfeval);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                  
%%%%%%%%% Plot prior and true dgp                      
% [priorsim_b, priorsim_mu, priorsim_alphaunn, priorsim_hy, priorsim_hx, priorsim_nuy, priorsim_nux, priorsim_m] ...
%          = prior_simulator(b_, Hb_, mu_, Hmu_, A_, Ahy_, Bhy_, Ahx_, Bhx_, Anuy_, Bnuy_, Anux_, Bnux_, Am_, Amlogp_, Nsim); 
% plotpostpdfdraws(101, ygridPlot, xgridPlot, priorsim_b, priorsim_mu, priorsim_alphaunn, priorsim_hy, priorsim_hx, priorsim_nuy, priorsim_nux, priorsim_m, Nsim, 1, q);
% plotdgpcpdf(101, ygridPlot, xgridPlot, dgpcpdfeval); 
% 
% if FlagRunNPkernelEst
%     plotnpcpdf(101, ygridPlot, xgridPlot, 1);
% end

%legend('post mean','0.0001 quantile', '0.9999 quantile', 'true', 'kernel'); xlabel('y'); ylabel('p(y|x)')

% compute RMSE and MAE as in Norets and Pelenis (2014)
%[rmse(mc_ind), mae(mc_ind)] = rmsemaepostcpdf(dgpcpdfeval, ygridPlot, xgridRMSE, sim_b(:,:,burnin:end), sim_mu(:,:,burnin:end), sim_alphaunn(:,burnin:end), sim_hy(:,burnin:end), sim_hx(:,burnin:end), sim_nuy(:,burnin:end), sim_nux(:,:,burnin:end), sim_m(:,burnin:end), Nsim-burnin+1, 1)
% the following lines call r package np, this would require changing
% paths  in npest.r, installing r and np package, setting paths for r, etc

% if FlagRunNPkernelEst
%     tic
%     [rmsenp(mc_ind), maenp(mc_ind)] = rmsemaenpcpdf(dgpcpdfeval, ygridPlot, xgridRMSE, 1)
%     msg = sprintf('NP Time = %d', toc); display(msg);
% end

%  tabrmse = [mean(rmse(1:mc_ind)), mean(rmsenp(1:mc_ind)), mean(rmse(1:mc_ind)-rmsenp(1:mc_ind)), mean(rmse(1:mc_ind)<rmsenp(1:mc_ind)), sqrt(length(rmse(1:mc_ind)))*mean(rmse(1:mc_ind)-rmsenp(1:mc_ind))./std(rmse(1:mc_ind)-rmsenp(1:mc_ind))]
%  tabmae = [mean(mae(1:mc_ind)), mean(maenp(1:mc_ind)), mean(mae(1:mc_ind)-maenp(1:mc_ind)), mean(mae(1:mc_ind)<maenp(1:mc_ind)),    sqrt(length(mae(1:mc_ind)))*mean(mae(1:mc_ind)-maenp(1:mc_ind))./std(mae(1:mc_ind)-maenp(1:mc_ind))]


end

% tabrmse = [mean(rmse), mean(rmsenp), mean(rmse-rmsenp), mean(rmse<rmsenp), sqrt(length(rmse))*mean(rmse-rmsenp)./std(rmse-rmsenp)]
% tabmae = [mean(mae), mean(maenp), mean(mae-maenp), mean(mae<maenp),    sqrt(length(mae))*mean(mae-maenp)./std(mae-maenp)]






%save('est11_23_16_dgp64.mat');
