function [yda,ydb] = create_trunc_bds(y, dd)
yda = y(1:dd,:)-0.5;
ydb = y(1:dd,:)+0.5;

for i = 1:dd
    minydai = min(yda(i,:));
    minind = find(yda(i,:) == minydai);
    yda(i, minind) = -inf;
	maxydbi = max(ydb(i,:));
    maxind = find(ydb(i,:) == maxydbi);
    ydb(i, maxind) = inf;
end