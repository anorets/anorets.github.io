%Explicitly check:    marginal_likelihood * posterior = likelihood * prior
% for multivariate normal with conjugate gamma-normal prior
% could be run from a breakpoint inside posterior simulator
loglklhdm = 0;
for i = 1:n
   if s(i) == m
        loglklhdm = loglklhdm + lnnormpdf(y(:,i),mu(:,m),diag(hy.*nuy(:,m)));
   end
end

logpriorm = sum(lngampdf(nuy(:,m),Anuy_,Bnuy_)) + lnnormpdf(mu(:,m), mu_, diag(nuy(:,m).*diag(Hmu_)));

Sy = y*mult_draw'; % (\sum_{s_i=1} y_i, ..., \sum_{s_i=m} y_i)
Sy2 = (y.^2)*mult_draw';
hNplusTau = (repmat(hy,1,m).*(N')+ diag(Hmu_));
barMu = (hy.*Sy + diag(Hmu_).*mu_)./ hNplusTau;
barBnuy = Bnuy_ + 0.5*(hy.*Sy2 + diag(Hmu_).*(mu_.^2) - hNplusTau.*barMu.^2);
barAnuy = Anuy_ + 0.5*repmat(N',d,1);
%nuy = gamrnd(barAnuy, 1./barBnuy);
%mu = normrnd(barMu, 1./sqrt(hNplusTau.*nuy));

logpost = sum(lngampdf(nuy(:,m),barAnuy(:,m),barBnuy(:,m))) + lnnormpdf(mu(:,m), barMu(:,m), diag(hNplusTau(:,m).*nuy(:,m)));

lml = log_ml(Sy, Sy2, N, hy, mu_, Hmu_, Anuy_, Bnuy_);

discrep = logpost + lml(m) - logpriorm - loglklhdm

discrep

