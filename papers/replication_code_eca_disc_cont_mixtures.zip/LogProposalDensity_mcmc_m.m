function lpdf = LogProposalDensity_mcmc_m(theta_mp1, prop_param)
lpdf = lnnormpdf(theta_mp1, prop_param{1}, prop_param{2});