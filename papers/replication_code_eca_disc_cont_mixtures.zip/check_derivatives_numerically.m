%check derivative numerically, go to this file from a breakpoint inside mcmc_ite_given_m.m

h = 0.0000001;
%[lpdf, Jlpdf, Hlpdf] = Ptildeyy_given_param(y, n, d, mu, alphaunn, hy, nuy, m, 1);

%Check derivatives wrt \mu_m or nuy_m
% [lpdf1, Jlpdf1, Hlpdf1] = Ptildeyy_given_param(y, n, d, mu , alphaunn, hy, nuy - [zeros(d,m-1), [0;h; zeros(d-2,1)]], m, 1);
% [lpdf2, Jlpdf2, Hlpdf2] = Ptildeyy_given_param(y, n, d, mu , alphaunn, hy, nuy+ [zeros(d,m-1), [0; h; zeros(d-2,1)]], m, 1);
% Jnum_der_dlklhd_dmu1 = (lpdf2 - lpdf1)./(2*h)
% Jlpdf(d+2)
% num_H = (Jlpdf2(d+2) - Jlpdf1(d+2))./(2*h)
% Hlpdf(d+2,d+2)

%Check derivatives wrt \alpaunn_m
% [lpdf1, Jlpdf1, Hlpdf1] = Ptildeyy_given_param(y, n, d, mu, alphaunn - [zeros(1,m-1), h]', hy, nuy, m, 1);
% [lpdf2, Jlpdf2, Hlpdf2] = Ptildeyy_given_param(y, n, d, mu, alphaunn + [zeros(1,m-1), h]', hy, nuy, m, 1);
% Jlpdf(2*d+1)
% num_der_dlklhd_dmu1 = (lpdf2 - lpdf1)./(2*h)
% num_H = (Jlpdf2(2*d+1) - Jlpdf1(2*d+1))./(2*h)
% Hlpdf(2*d+1,2*d+1)

%check cross derivatives
% [lpdf1, Jlpdf1, Hlpdf1] = Ptildeyy_given_param(y, n, d, mu - [zeros(d,m-1), [0; h; zeros(d-2,1)]], alphaunn, hy, nuy, m, 1);
% [lpdf2, Jlpdf2, Hlpdf2] = Ptildeyy_given_param(y, n, d, mu + [zeros(d,m-1), [0; h; zeros(d-2,1)]], alphaunn, hy, nuy, m, 1);
% Jlpdf(2)
% num_der_dlklhd_dmu1 = (lpdf2 - lpdf1)./(2*h)
% num_H = (Jlpdf2(2*d+1) - Jlpdf1(2*d+1))./(2*h)
% Hlpdf(2*d+1,2)

% Check for prior


[lpdf, Jlpdf, Hlpdf] = lprior_nuy_mu_alphaunn_mJH(mu, alphaunn, nuy, m, mu_, Hmu_, A_, Anuy_, Bnuy_, 1);

%Check derivatives wrt \mu_m or nuy_m
% [lpdf1, Jlpdf1, Hlpdf1] = lprior_nuy_mu_alphaunn_mJH(mu, alphaunn, nuy - [zeros(d,m-1), [0;h; zeros(d-2,1)]], m, mu_, Hmu_, A_, Anuy_, Bnuy_, 1);
% [lpdf2, Jlpdf2, Hlpdf2] = lprior_nuy_mu_alphaunn_mJH(mu, alphaunn, nuy + [zeros(d,m-1), [0;h; zeros(d-2,1)]], m, mu_, Hmu_, A_, Anuy_, Bnuy_, 1);
% Jnum_der_dlklhd_dmu1 = (lpdf2 - lpdf1)./(2*h)
% Jlpdf(d+2)
% num_H = (Jlpdf2(d+2) - Jlpdf1(d+2))./(2*h)
% Hlpdf(d+2,d+2)

[lpdf1, Jlpdf1, Hlpdf1] = lprior_nuy_mu_alphaunn_mJH(mu, alphaunn -[zeros(m-1,1);h], nuy, m, mu_, Hmu_, A_, Anuy_, Bnuy_, 1);
[lpdf2, Jlpdf2, Hlpdf2] = lprior_nuy_mu_alphaunn_mJH(mu, alphaunn +[zeros(m-1,1);h], nuy, m, mu_, Hmu_, A_, Anuy_, Bnuy_, 1);
Jnum_der_dlklhd_dmu1 = (lpdf2 - lpdf1)./(2*h)
Jlpdf(2*d+1)
num_H = (Jlpdf2(2*d+1) - Jlpdf1(2*d+1))./(2*h)
Hlpdf(2*d+1,2*d+1)


%check cross derivatives
[lpdf1, Jlpdf1, Hlpdf1] = lprior_nuy_mu_alphaunn_mJH(mu, alphaunn, nuy - [zeros(d,m-1), [0;h; zeros(d-2,1)]], m, mu_, Hmu_, A_, Anuy_, Bnuy_, 1);
[lpdf2, Jlpdf2, Hlpdf2] = lprior_nuy_mu_alphaunn_mJH(mu, alphaunn, nuy + [zeros(d,m-1), [0;h; zeros(d-2,1)]], m, mu_, Hmu_, A_, Anuy_, Bnuy_, 1);

num_H = (Jlpdf2(2) - Jlpdf1(2))./(2*h)
Hlpdf(d+2,2)

