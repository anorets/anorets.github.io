% MCMC update of 
% (b, mu, alphaunn, hy, hx, nuy, nux) | m 


function [y,  mu, alphaunn, hy, nuy, m, hyAccCount] ...
         = mcmc_iter_given_m(y, yda, ydb, n, d, dd, ...
                                mu, alphaunn, hy, nuy, m,...
                                hyAccCount, ...
                                mu_, Hmu_, A_, Ahy_, Bhy_, Anuy_, Bnuy_, Am_, Amlogp_)

alpha = alphaunn./sum(alphaunn);

% Block for s %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Q = ComputeQ(n, m, dx, x, mu, nux, hx);
%[aexpQnorm, sumlogsumkaexpQ] = Qnormsumlogsum(Q,alpha);
if m> 1
    Qy = bsxfun(@minus, repmat(y',1,m), reshape(mu,1,m*d));
    Qy = bsxfun(@times, Qy.^2, reshape(nuy.*hy,1,m*d));
    SQy = reshape(sum(reshape(Qy',d,m*n),1), m, n)';
    SQy = -0.5*(SQy-sum(log(nuy),1)) + log(alpha');
    Q = exp(SQy - repmat(max(SQy,[],2), 1, m)); %avoiding numerical over/under flow
    Q = bsxfun(@rdivide, Q, sum(Q,2)); 
    mult_draw = mnrnd(1,Q)';
    [s, col] = find(mult_draw);
else
    s = ones(n,1);
    mult_draw = ones(1,n);
end
N = sum(mult_draw,2);

% %block for latent variables
if dd
    muy = mu(1:dd,s); 
    sdy = 1./sqrt(hy(1:dd,1).*nuy(1:dd,s)); 
    try
    y(1:dd,:) = truncnormrnd(muy,sdy,yda,ydb); 
    catch
        stop = 1;
    end
end



% %end block for latent variables

%y(1:dd,:) = normrnd(muy,sdy);

alpha = gamrnd(A_./m+N,1);
alpha = alpha ./ sum(alpha);
alphaunn = alpha*gamrnd(A_,1);


%%%%%%%%%%%Block for nuy and mu
Sy = y*mult_draw'; % (\sum_{s_i=1} y_i, ..., \sum_{s_i=m} y_i)
Sy2 = (y.^2)*mult_draw';
hNplusTau = (repmat(hy,1,m).*(N')+ diag(Hmu_));
barMu = (hy.*Sy + diag(Hmu_).*mu_)./ hNplusTau;
barBnuy = Bnuy_ + 0.5*(hy.*Sy2 + diag(Hmu_).*(mu_.^2) - hNplusTau.*barMu.^2);
barAnuy = Anuy_ + 0.5*repmat(N',d,1);
nuy = gamrnd(barAnuy, 1./barBnuy);
mu = normrnd(barMu, 1./sqrt(hNplusTau.*nuy));
%%%%%%%%%%%Block for nuy and mu


% block for hy 
eps2 = (y-mu(:,s)).^2;
Ahy = Ahy_.*0.5 + n/2;
Bhy = 0.5*sum(eps2.*nuy(:,s),2);
hy_p = gamrnd(Ahy, 1./Bhy);
if rand < exp(-sum(Bhy_.*(hy_p.^0.5-hy.^0.5)))
   hy = hy_p;
   hyAccCount = hyAccCount + 1;
end  

% this is for for cond conjugate prior on hy, commented out
% Ahy = Ahy_ + n/2;
% Bhy = Bhy_ + 0.5*sum(eps2.*nuy(:,s),2);
% hy = gamrnd(Ahy, 1./Bhy); %uncomment this and above 2 lines for conjugate case instead of the following lines