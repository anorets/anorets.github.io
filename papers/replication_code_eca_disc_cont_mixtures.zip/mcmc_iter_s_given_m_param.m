% MCMC update of s

function  [s, mult_draw, N] = mcmc_iter_s_given_m_param(y, n, d, mu, alphaunn, hy, nuy, m)

alpha = alphaunn./sum(alphaunn);

% Block for s %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Q = ComputeQ(n, m, dx, x, mu, nux, hx);
%[aexpQnorm, sumlogsumkaexpQ] = Qnormsumlogsum(Q,alpha);
if m> 1
    Qy = bsxfun(@minus, repmat(y',1,m), reshape(mu,1,m*d));
    Qy = bsxfun(@times, Qy.^2, reshape(nuy.*hy,1,m*d));
    SQy = reshape(sum(reshape(Qy',d,m*n),1), m, n)';
    SQy = -0.5*(SQy-sum(log(nuy),1)) + log(alpha');
    Q = exp(SQy - repmat(max(SQy,[],2), 1, m)); %avoiding numerical over/under flow
    Q = bsxfun(@rdivide, Q, sum(Q,2)); 
    mult_draw = mnrnd(1,Q)';
    [s, col] = find(mult_draw);
else
    s = ones(n,1);
    mult_draw = ones(1,n);
end
N = sum(mult_draw,2);