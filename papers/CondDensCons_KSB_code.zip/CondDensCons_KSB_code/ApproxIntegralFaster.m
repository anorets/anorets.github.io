function Int=ApproxIntegralFaster(Xgrid,Ygrid,prior)
    for t=1:size(Xgrid,1);
%         nsimInt=1e5;
        nsimInt=1e4;
        mu=mvnrnd(prior.beta_mu, inv(prior.beta_H),nsimInt);
        sigma2=1./gamrnd(ones(nsimInt,1)*prior.sigma_shape, ones(nsimInt,1)*prior.sigma_scale)';
        den=1./sqrt(2*pi.*sigma2);
        CovDepMean=(mu*[1;Xgrid(t)])';
        Yf=(repmat(Ygrid,1,nsimInt)-repmat(CovDepMean,size(Ygrid,1),1)).^2;
        numf=exp(-.5*Yf./repmat(sigma2,size(Ygrid,1),1));
        Int(:,t)=sum(repmat(den,size(Ygrid,1),1).*numf,2)./nsimInt;        
    end        

