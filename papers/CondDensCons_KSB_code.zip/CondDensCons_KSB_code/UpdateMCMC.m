function param=UpdateMCMC(X,Y,param,prior)
% Below are separate MCMC Blocks as described in Appendix 9.1.
param=updateBetaSigma(X,Y,param,prior); % Block 1 
param=updatealpha(X,param,prior); % Block 2
param=Updateq(X,param,prior); % Block 3
param=UpdateQ(X,param,prior); % Block 4
param=updateU(X,param); % Block 5
param=updateparamsextra(X,param,prior); % Block 6
param=updateZ(Y,X,param); % Block 7

% Block 1 described in Appendix 9.1.
function param=updateBetaSigma(X,Y,param,prior)
    M=size(param.beta,1);
    T=size(Y,1);
    OO=repmat(1:1:M,T,1);
    ZZ=repmat(param.Z',1,M);
    ZE=OO==ZZ;
    Tj=sum(ZE);
    YY=repmat(Y,1,M);
    YZ=YY.*ZE;
    Ytj=sum(YZ);
    XX=repmat(X,1,M);
    XXtj=sum(XX.*ZE);
    X2=repmat(X.^2,1,M);
    X2tj=sum(X2.*ZE);
    XY=repmat(X.*Y,1,M);
    XYtj=sum(XY.*ZE);
    X1=[ones(T,1) X]';
    Mi=(param.beta*X1)';
    YM=(YY-Mi).^2;
    YZ2=YM.*ZE;
    Ymtj=sum(YZ2);
    shape=prior.sigma_shape+.5*Tj;
    scale=1./(1/prior.sigma_scale+0.5*Ymtj);
    %     Update \sigma^2.
    param.sigma=sqrt(1./gamrnd(shape, scale));
    %     Update \beta.
    for j=1:M 
        VVV=inv(prior.beta_H+[Tj(j) XXtj(j); XXtj(j) X2tj(j) ]/param.sigma(j)^2);
        mid=VVV*(prior.beta_H*prior.beta_mu'+[Ytj(j); XYtj(j)]/param.sigma(j).^2);
        param.beta(j,:)=mvnrnd(mid,VVV);
    end

% Block 2 described in Appendix 9.1.
function param=updatealpha(X,param,prior)
    M=size(param.alpha,2);
    T=size(X,1);
    ZE=bsxfun(@eq,param.Z',1:M);
    Zbelow=bsxfun(@gt,param.Z',1:M);
    HH=exp(bsxfun(@times,-param.Q,bsxfun(@minus,param.q',X).^2));
    denO=log(1-param.alpha);
    numOhelp=log(1-repmat(param.alpha,T,1).*HH);
    numO=sum(Zbelow.*numOhelp);
    ratioPropO=numO./denO;
    % This is the proposal for \alpha_j^* as suggested in Step 2
    prop=betarnd(prior.alpha_a+sum(ZE),prior.alpha_b+ratioPropO);
    denN=log(1-prop);
    numNhelp=log(1-repmat(prop,T,1).*HH);
    numN=sum(Zbelow.*numNhelp);
    ratioPropN=numN./denN;
    qNO=betapdf(prop,prior.alpha_a+sum(ZE),prior.alpha_b+ratioPropO);
    logpNew=log(betapdf(prop,prior.alpha_a,prior.alpha_b))+sum(ZE).*log(prop)+numN;
    qON=betapdf(param.alpha,prior.alpha_a+sum(ZE),prior.alpha_b+ratioPropN);
    logpOld=log(betapdf(param.alpha,prior.alpha_a,prior.alpha_b))+sum(ZE).*log(param.alpha)+numO;
    % The MH acceptance probability as described in (B.2)
    AcceptProb=exp(logpNew-logpOld).*qON./qNO;
    AcceptProb(isnan(AcceptProb))=0;
    u=rand(1,M);
    param.alpha=(u<AcceptProb).*prop+(AcceptProb<u).*param.alpha; 

%  Block 3 described in Appendix 9.1.
function param=Updateq(X,param,prior)
    M=size(param.q,1);
    T=size(X,1);
    AA=bsxfun(@times,-param.Q,bsxfun(@minus,param.q',X).^2);
    LA=log(1-repmat(param.alpha,T,1).*exp(AA));
    ZE=bsxfun(@eq,param.Z',1:M);
    Zbelow=bsxfun(@gt,param.Z',1:M);
    FP=AA.*ZE;
    SP=LA.*Zbelow;
    LLold=sum(FP)+sum(SP);
    Nj=sum(ZE);
    % Random walk proposal as in Appendix 9.1.
    % This random walk proposal can be adjusted.
    rw=(2*param.Q.*Nj+4).^-.5;
    qNew=normrnd(0,rw)'+param.q;
    AAN=bsxfun(@times,-param.Q,bsxfun(@minus,qNew',X).^2);
    LAN=log(1-repmat(param.alpha,T,1).*exp(AAN));
    FPN=AAN.*ZE;
    SPN=LAN.*Zbelow;
    LLnew=sum(FPN)+sum(SPN);
    % Adjust for prior support bounds on [prior.q_ub, prior.q_lb]
    OutOfBounds=(qNew<prior.q_lb)+(qNew>prior.q_ub);
    OutOfBounds(OutOfBounds>0)=-Inf;
    LLnew=LLnew+OutOfBounds';
    AcceptProb=exp(LLnew-LLold)';
    u=rand(M,1);
    param.q=param.q.*(u>AcceptProb)+qNew.*(u<AcceptProb);

%  Block 4 described in Appendix 9.1.
function param=UpdateQ(X,param,prior)
    M=size(param.beta,1);
    T=size(X,1);
    HH=bsxfun(@minus,param.q',X).^2;
    VV=repmat(param.alpha,T,1);
    Lead=VV.*exp(-repmat(param.Q,T,1).*HH);
    Follow=log((1-Lead));
    LogPij=log(Lead);
    ZE=bsxfun(@eq,param.Z',1:M);
    Zbelow=bsxfun(@gt,param.Z',1:M);
    LLold=sum(ZE.*LogPij+Zbelow.*Follow);
    % Random walk proposal as in Appendix 9.1.
    % This random walk proposal can be adjusted
    QNew=param.Q+normrnd(0, 0.5 , 1, M); 
    Lead=VV.*exp(-repmat(QNew,T,1).*HH);
    Follow=log((1-Lead));
    LogPij=log(Lead);
    LLnew=sum(ZE.*LogPij+Zbelow.*Follow);
    priorfactor=exp(-(-param.Q+QNew)/prior.Q_tau);
    AcceptProb=exp(LLnew-LLold).*priorfactor; 
    u=rand(1,M);    
    param.Q=(QNew>0).*((u<AcceptProb).*QNew+(u>AcceptProb).*param.Q)+(QNew<0).*param.Q;

%  Block 5 described in Appendix 9.1.
function param=updateU(X,param)
    global Lead Follow Pij;
    T=size(param.Z,2);
    Lead=bsxfun(@times,param.alpha,exp(bsxfun(@times,-param.Q,bsxfun(@minus,param.q',X).^2)));
    Follow=log((1-Lead));
    Pij=Lead.*exp([zeros(T,1) cumsum(Follow(:,1:end-1),2)]);
    Cut=Pij((param.Z-1)*T+[1:1:T])';
    if size(Cut,2)>1
        Cut=Cut';
    end
    param.U=rand(T,1).*Cut;

%  Block 6 described in Appendix 9.1.
function param=updateparamsextra(X,param,prior)
    global Lead Follow Pij;
    M=size(param.beta,1);
    T=size(param.Z,2);
    ii=0;   Inc=M; 
    % Check whether the condition in Equation (B.4) is satisfied.
    while sum((1-sum(Pij,2))>param.U)>0
        ii=ii+1;
        % generate new variables in batches of Inc for computational speed purposes.
        alphaNew=betarnd(prior.alpha_a,prior.alpha_b,Inc,1);
        sigmaNew=sqrt(1./gamrnd(prior.sigma_shape, prior.sigma_scale,Inc,1));
        betaNew=mvnrnd(prior.beta_mu, inv(prior.beta_H),Inc);
        qNew=prior.q_lb+rand(Inc,1)*(prior.q_ub-prior.q_lb);
        QNew=exprnd(prior.Q_tau,Inc,1);
        if mod(ii,100)==0
             display('This is very unlikely. Check whether the priors are reasonable');
             break
        end
        param.alpha(M+(ii-1)*Inc+1:M+ii*Inc)=alphaNew;
        param.sigma(M+(ii-1)*Inc+1:M+ii*Inc)=sigmaNew;
        param.beta(M+(ii-1)*Inc+1:M+ii*Inc,:)=betaNew;
        param.q(M+(ii-1)*Inc+1:M+ii*Inc,1)=qNew;
        param.Q(M+(ii-1)*Inc+1:M+ii*Inc)=QNew;
        Lead=bsxfun(@times,param.alpha,exp(bsxfun(@times,-param.Q,bsxfun(@minus,param.q',X).^2)));
        Follow=log((1-Lead));
        Pij=Lead.*exp([zeros(T,1) cumsum(Follow(:,1:end-1),2)]);
    end

%  Block 7 described in Appendix 9.1.
function param=updateZ(Y,X,param)
    global Lead Follow Pij;
    M=size(param.beta,1);
    T=size(Y,1);
    Check=bsxfun(@gt,Pij,param.U);
    X1=[ones(T,1) X]';
    Mi=(param.beta*X1)';
    YY=(repmat(Y,1,M)-Mi).^2;
    sigma2=param.sigma.^2;
    SS2=repmat(sigma2,T,1);
    npdf=(exp(-.5*YY./SS2)./sqrt(2*pi*SS2));
    npdf(isnan(npdf))=0;
    Propto=Check.*npdf;
    Normprop=bsxfun(@times,Propto,1./sum(Propto,2));
    CumNorm=[zeros(T,1) cumsum(Normprop(:,1:end-1),2)];
    TTT=bsxfun(@lt,CumNorm,rand(T,1));
    [rowIdx,colIdx] = find(TTT);
    param.Z=accumarray(rowIdx,colIdx,[],@max)';
    M=max(param.Z);
    param.alpha=param.alpha(1:M);         
    param.beta=param.beta(1:M,:);
    param.sigma=param.sigma(1:M);
    param.q=param.q(1:M);
    param.Q=param.Q(1:M);

 
