function [pval]=SepPartialMeanTest(param1,moment)
[k,j,i]=size(moment);
MM=k*j*i;
[rows,cols,arrs]=size(param1);
len_4 = round(length(param1(1,1,:))/4)-1;
filter = len_4+1:1:2*len_4;
filter2 = 3*len_4+1:1:4*len_4;
for m=1:MM
   for  r=1:rows
       for c=1:cols
           x=squeeze(param1(r,c,filter)).^moment(m);
           y=squeeze(param1(r,c,filter2)).^moment(m);
           % Now compute the p-value for the separated partial means test
           mean_x=mean(x);
           mean_y=mean(y);
           dx=x-mean_x;
           dy=y-mean_y;
           NSEsq_x=var(x);
           NSEsq_y=var(y);           
           % Account for some serial correlation 
           L=floor(power(len_4,0.4));
           for l=1:L-1
               NSEsq_x=NSEsq_x+((L-l)/L)*2*dx(1:end-l)'*dx(1+l:end)/size(x,1);
               NSEsq_y=NSEsq_y+((L-l)/L)*2*dy(1:end-l)'*dy(1+l:end)/size(y,1);
           end
           mean_eqlty_stat(r,c,m) = (mean_x - mean_y)^2/(NSEsq_x+NSEsq_y)*len_4;
           pval(r,c,m)=1-gammainc(mean_eqlty_stat(r,c,m)/2,0.5);
       end
   end
   display(['convergence diagnostics for moment - ',num2str(moment(m))]);
   display(['pvalue of test statistic']);
   [pval(:,:,moment(m))]
end
