Matlab functions and scripts that implement the algorithm from "Posterior Consistency in Conditional Density Estimation" by Andriy Norets and Justinas Pelenis.

1. Script ReplicateFigure1.m illustrates the use of function UpdateMCMC to produce an equivalent to Figure 1 in the paper. 

2. Script ReplicateTable1.m illustrates the use of function UpdateMCMC to produce the equivalent results of Table 1 in the paper.
(the code has been slightly modified that resulted in insignificantly different results to the ones in the paper)

2. Script ReplicateTable2.m illustrates the use of function UpdateMCMC to produce the equivalent results of Table 2 in the paper.
(the code has been slightly modified that resulted in insignificantly different results to the ones in the paper)

4. Function UpdateMCMC.m implements the posterior simulator for parameters.

5. Function InitializeMCMC.m draws parameters (and conditional data) from the prior distribution. 

6. Function ComputeCondDensity_GenY.m computes conditional standard density given posterior draws and dependent and independent variables and generates a draw of covariate Y given X.

7. Function SepPartialMeanTest.m performs a separated partial means test. 

8. Functions ApproxIntegral.m and ApproxIntegralFaster.m are supplementary functions.