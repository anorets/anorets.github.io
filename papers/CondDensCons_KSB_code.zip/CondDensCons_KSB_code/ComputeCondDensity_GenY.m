function [YcXdens GenY]=ComputeCondDensity_GenY(Y,X,param,prior,CovIntColumn)
    M=size(param.beta,1);
    TT=size(Y,1); T=1;
    Lead=repmat(param.alpha,T,1).*exp(-repmat(param.Q,T,1).*(repmat(param.q',T,1)-repmat(X(1),1,M)).^2);
    Follow=log((1-Lead));
    UD=triu(ones(M,M),1);
    LogPij=log(Lead)+Follow*UD;
    Prob=exp(LogPij);
    ii=0;
    Inc=M; % Random number generation in batches - faster.
    while sum((1-sum(Prob,2))>1e-4)>0
        ii=ii+1;
        alphaNew=betarnd(prior.alpha_a,prior.alpha_b,Inc,1);
        sigmaNew=sqrt(1./gamrnd(prior.sigma_shape, prior.sigma_scale,Inc,1));
        betaNew=mvnrnd(prior.beta_mu, inv(prior.beta_H),Inc);
        qNew=prior.q_lb+rand(Inc,1)*(prior.q_ub-prior.q_lb);
        QNew=exprnd(prior.Q_tau,Inc,1);
        if mod(ii,100)==0
            % To prevent the loop from running too long. 
            display('This is very unlikely. Check whether priors are reasonable');
            break
        end
        param.alpha(M+(ii-1)*Inc+1:M+ii*Inc)=alphaNew;
        param.sigma(M+(ii-1)*Inc+1:M+ii*Inc)=sigmaNew;
        param.beta(M+(ii-1)*Inc+1:M+ii*Inc,:)=betaNew;
        param.q(M+(ii-1)*Inc+1:M+ii*Inc,1)=qNew;
        param.Q(M+(ii-1)*Inc+1:M+ii*Inc)=QNew;
        Lead=bsxfun(@times,param.alpha,exp(bsxfun(@times,-param.Q,bsxfun(@minus,param.q',X(1)).^2)));
        Follow=log((1-Lead));
        Prob=Lead.*exp([zeros(1,1) cumsum(Follow(:,1:end-1),2)]);
    end
    Leftover=1-sum(Prob,2);
    J_l=size(param.beta,1);
    mf=(param.beta*[1;X(1)])';
    YY=(repmat(Y,1,J_l)-repmat(mf,TT,1)).^2;
    sigma2=param.sigma.^2;
    npdf=exp(-.5*YY./repmat(sigma2,TT,1))./sqrt(2*pi*repmat(sigma2,TT,1));
    npdf(isnan(npdf))=0;
% This is Equation (B.5) in the Appendix 9.2.
    YcXdens=npdf*Prob'+Leftover.*CovIntColumn;
    
% Furthermore, one can generate a sample of GenY draws conditional on the
% covariate X and use those to check convergence. 
    u=rand;
    if u>sum(Prob,2)
        % generate from the prior!
        betaN(1,:)=mvnrnd(prior.beta_mu, inv(prior.beta_H) );
        sigmaN=sqrt(1/gamrnd(prior.sigma_shape, prior.sigma_scale, 1, 1));
        GenY=normrnd(betaN*[1; X(1)], sigmaN, 1,1);
    else
        State=find(u<cumsum(Prob),1,'first');
        GenY=normrnd(param.beta(State,:)*[1; X(1)], param.sigma(State), 1,1);
    end

    

