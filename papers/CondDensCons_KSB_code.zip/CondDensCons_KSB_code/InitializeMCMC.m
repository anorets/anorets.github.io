function [param Y]=InitializeMCMC(X,prior)
T=size(X,1);
smax=0;
for j=1:T
    ss=1;
    u=rand;
    kk=0;
    while ss<=smax
       W=param.alpha(ss)*exp(-param.Q(ss)*sum((param.q(ss,:)-X(j,:)).^2));
       if u<W
           param.Z(j)=ss; % allocate latent state to one of the existing ones.
           ss=smax+1;
           kk=1;
       else
           u=(u-W)/(1-W);
           ss=ss+1;
       end
    end
    while kk==0
        % generate a new set of parameters from the prior for the latent
        % state allocation
        alphaNew=betarnd(prior.alpha_a,prior.alpha_b);
        qNew=prior.q_lb+rand(1,1)*(prior.q_ub-prior.q_lb);
        QNew=exprnd(prior.Q_tau);
        W=alphaNew*exp(-QNew*sum((qNew-X(j,:)).^2));
        smax=smax+1;
        param.alpha(smax)=alphaNew;
        param.Q(smax)=QNew;
        param.q(smax,:)=qNew;
        param.beta(smax,:)=mvnrnd(prior.beta_mu, inv(prior.beta_H) );
        param.sigma(smax)=sqrt(1/gamrnd(prior.sigma_shape, prior.sigma_scale, 1, 1));
        if u<W
            kk=1;
            param.Z(j)=smax; 
        else
            u=(u-W)/(1-W);
        end
    end
    if param.Z(j)>1
        pzj=param.alpha(param.Z(j))*exp(-param.Q(param.Z(j))*(X(j)-param.q(param.Z(j))).^2)*prod(1-param.alpha(1:param.Z(j)-1).*exp(-param.Q(param.Z(j)).*((X(j)-param.q(1:param.Z(j)-1)).^2))');
    else
        pzj=param.alpha(param.Z(j))*exp(-param.Q(param.Z(j))*(X(j)-param.q(param.Z(j))).^2);
    end
    param.U(j,1)=rand*pzj; % latent variable for slice sampling
    
    % generate dependent variable Y from this KSB process if one desires to
    % have dependent data generated from the model.
    Y(j,1)=normrnd(param.beta(param.Z(j),:)*[1; X(j)], param.sigma(param.Z(j)), 1,1);
end

