% Set up first a simple prior simulator for my model. 

clear; 
close all; 

MCsim=1e2;

T=5e2;
prior.alpha_a=1; 
prior.alpha_b=.5; 
prior.Q_tau=1/(prior.alpha_a+prior.alpha_b);
prior.q_lb=0; % lower bound on the support of covariates
prior.q_ub=1; % upper bound on the support of covariates

Xgrid=[0.01:0.02:.99]';
Ygrid=[-0.88:0.04:1.08]';
TY=size(Ygrid,1);
TX=size(Xgrid,1);
nsim2=1e4; % Number of iterations for each sample out of MCsim samples.

tic
for ii=1:MCsim
    seednumber=ii; randn('seed',seednumber);rand('seed',seednumber);
    
    % Generate X and Y
    X=prior.q_lb+rand(T,1)*(prior.q_ub-prior.q_lb);
    % DGP from Dunson and Park paper.
    U=rand(T,1);
    Y=(U<exp(-2*X)).*normrnd(X,0.1)+(U>exp(-2*X)).*normrnd(X.^4,0.2);
        
    % Need to compute true conditional densities.
    for t=1:TX
        Xf=ones(TY,1)*Xgrid(t,1); 
        YdMC(:,t,ii)=exp(-2*Xf).*normpdf(Ygrid,Xf,0.1)+(1-exp(-2*Xf)).*normpdf(Ygrid,Xf.^4,0.2);
    end
   
    % Data dependent prior choices.
    prior.beta_mu=[mean(Y) 0];
    prior.beta_H=diag([inv(var(Y)*2) ,1]);
    prior.sigma_scale=inv(var(Y)/2);
    prior.sigma_shape=3;
    
    % This should be replaced by ApproxIntegral
    CovInt=ApproxIntegralFaster(Xgrid,Ygrid,prior);
    
    % Draw initial starting parameter values from the prior. 
        param=InitializeMCMC(X,prior);
    
    kk=0;
    %Posterior simulator
    for j=1:nsim2
        % Below is the function that performs one MCMC iteration    
        param=UpdateMCMC(X,Y,param,prior);
        if mod(j,20)==0         
            kk=kk+1;
            for t=1:TX
                CopyXgrid1=ones(size(Ygrid,1),1)*Xgrid(t,1);
                [YdCC(:,t,kk)]=ComputeCondDensity_GenY(Ygrid,CopyXgrid1,param,prior,CovInt(:,t));
            end
        end
        
% This simply an indicator of how many MCMC iterations have passed.  
        if mod(j,1000)==0
            display(['Iteration number - ',num2str(j),'/',num2str(nsim2),'. DGP process - ',num2str(ii),'/',num2str(MCsim),'. Time taken - ',num2str(toc),' seconds.']);
        end
    end
    
    % Find the mean of the predictive density.
    YdCC=YdCC(:,:,end/4:end);
    YpCC(:,:,ii)=mean(YdCC,3);
end

% Compute means and st devs of RMSE and MAE 
for ii=1:MCsim
    RMSE(ii)=sqrt(sum(sum((YdMC(:,:,ii)-YpCC(:,:,ii)).^2))/(TX*TY));
    MAE(ii)=sum(sum(abs(YdMC(:,:,ii)-YpCC(:,:,ii))))/(TX*TY);
end
[mean(RMSE) std(RMSE) mean(MAE) std(MAE)]