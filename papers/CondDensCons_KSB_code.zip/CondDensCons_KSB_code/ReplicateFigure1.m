% Reproduction of figure 1 in Norets and Pelenis (2013) `Posterior
% Consistency in Conditional Density Estimation by Covariate Dependent
% Mixtures'.

clear; close all; tic;
seednumber=1;randn('seed',seednumber);rand('seed',seednumber);

% True Data Generating Process as in Equation (6.3) and taken from Dunson
% and Park (2008) `Kernel Stick-Breaking Process'.

    % We will evaluate conditional densities for a select set of covariate
    % values and for a grid of dependent variable.
    Xgrid=[0.25;0.5;0.75]; % Select covariate values.
    Ygrid=[-0.9:0.01:1.3]'; % Values of variable y for which conditional density is evaluated.
    for t=1:size(Xgrid,1)
        Xones=ones(size(Ygrid,1),1)*Xgrid(t,1); 
        YtrueCondDens(:,t)=exp(-2*Xones).*normpdf(Ygrid,Xones,0.1)+(1-exp(-2*Xones)).*normpdf(Ygrid,Xones.^4,0.2);
    end
    
% Initialize the prior with fixed non-data dependent hyperparameters. 
% See equation (6.2) in the paper
    prior.alpha_a=1; 
    prior.alpha_b=.5; 
    prior.Q_tau=1/(prior.alpha_a+prior.alpha_b);
    prior.q_lb=0; % lower bound on the support of covariates
    prior.q_ub=1; % upper bound on the support of covariates

% Select the different sample sizes for which to perform the simulation for
% the given DGP.
    N2=[2e2 5e2 2e3];
    
% Specify the number of MCMC draws and the trimming parameter
    nsim=4e4; % Number of posterior draws
    trim=20; % every 20-th draw is used to compute an estimate of the conditional density
    burn_in=floor(nsim/4);
    
% Perform MCMC for each specific sample size    
    for ii=1:max(size(N2))
        randn('seed',seednumber); rand('seed',seednumber);kk=0;
    
    % first generate the data from the DGP specified in Equation (6.3)
        N=N2(ii); 
        X=prior.q_lb+rand(N,1)*(prior.q_ub-prior.q_lb);
        U=rand(N,1);
        Y=(U<exp(-2*X)).*normrnd(X,0.1)+(U>exp(-2*X)).*normrnd(X.^4,0.2);
        
    % Complete the choice of the prior data-dependent hyperparameters as in Equation (6.2)
        prior.beta_mu=[mean(Y) 0];
        prior.beta_H=diag([inv(var(Y)*2) ,1]);
        prior.sigma_scale=inv(var(Y)/2);
        prior.sigma_shape=3;
        
    % Approximate by simulation the integral that depends only on the prior
    % hyperparameters and covariates which is given in Equation (B.5)
        CovInt=ApproxIntegral(Xgrid,Ygrid,prior);
        
    % Draw initial starting parameter values from the prior. (can be used to generate dependent observable Y from the KSB model given X as well). 
        param=InitializeMCMC(X,prior);
        
    % Perform the MCMC step
        for j=1:nsim
            param=UpdateMCMC(X,Y,param,prior);
        % Uncomment below to alternatively store all of the MCMC draws from the posterior.
        %     param(j+1)=UpdateMCMC(X,Y,param(j),prior);
        
            if (mod(j,trim)==0) && (j>burn_in)
                kk=kk+1;
            % Compute conditinional densities given parameter draws from
            % the MCMC run and generate a draw from p(y|x) given Xgrid.
                for t=1:size(Xgrid,1)
                    CopyXgrid1=ones(size(Ygrid,1),1)*Xgrid(t,1);
                    [YcXdens(:,t,kk) GenY(:,t,kk)]=ComputeCondDensity_GenY(Ygrid,CopyXgrid1,param,prior,CovInt(:,t));
                end
            end
        % This simply an indicator of how many MCMC iterations have passed.  
            if mod(j,2000)==0  
                display(['Iteration number - ',num2str(j),'/',num2str(nsim),'. Sample size choice - ',num2str(ii),'/',num2str(max(size(N2))),'. Time taken - ',num2str(toc),' seconds.']);
            end
        end
        
    % Uncomment the text below to compute the p-values for the separated
    % partial means tests for conditional density estimates
         [pVal]=SepPartialMeanTest(GenY,[1 2]);
         pValAll(:,ii)=reshape(pVal,numel(pVal),1);
       
    % Plotting Figure 1 in the manuscript.    
        figure(1)
        hold on
        nn=size(YcXdens,3);
        KK=size(Xgrid,1);
    % Plot conditional densities for varying values of covariate Xgrid.
        for k=1:KK
            subplot(max(size(N2)),KK,k+(ii-1)*KK);    
            axis([-0.9 1.3 0 4]);
            plot(Ygrid,YtrueCondDens(:,k),'k','LineWidth', 1.5);
            hold on
            if (ii==1)
                title(['\fontsize{18}x = ',num2str(Xgrid(k))]);
            end
            if k==1
                 ylabel(['\fontsize{18}N = ',num2str(N2(ii))]);
            end
            xlabel('\fontsize{18}y');
            AA=squeeze(YcXdens(:,k,:));
            BB=sort(AA,2);
            axis([-0.9 1.3 0 4]);
            plot(Ygrid,mean(YcXdens(:,k,:),3),'k--','LineWidth', 1.5); 
            plot(Ygrid,BB(:,floor(nn*0.005)),'k:','LineWidth', 1.5);  
            plot(Ygrid,BB(:,floor(nn*0.995)),'k:','LineWidth', 1.5); 
            set(gca,'fontsize',14)
        end
    
    end
   
